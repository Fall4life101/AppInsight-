
# APK Installation Troubleshooting Guide

## Common Installation Issues & Solutions

### 1. **"App not installed" Error**

**Causes & Solutions:**
- **Insufficient storage**: Free up at least 100MB of space
- **Corrupted APK**: Re-download or rebuild the APK
- **Architecture mismatch**: Ensure APK is built for your device architecture

### 2. **"Unknown sources" Block**

**Solution:**
1. Go to **Settings** > **Security** (or **Privacy**)
2. Enable **"Unknown sources"** or **"Install unknown apps"**
3. For Android 8+: Enable for the specific browser/file manager you're using

### 3. **"Parse error" or "There was a problem parsing the package"**

**Causes & Solutions:**
- **Incomplete download**: Re-download the APK file
- **File corruption**: Transfer APK again via USB/email
- **Android version incompatibility**: Check if your Android version is supported (need Android 7+)

### 4. **"Package conflicts with an existing package"**

**Solution:**
1. **Uninstall any existing version** of AppInsight
2. Go to **Settings** > **Apps** > find **AppInsight** > **Uninstall**
3. Try installing the new APK again

### 5. **Permission Issues**

**Solution:**
After installation:
1. Open **Settings** > **Apps** > **AppInsight** > **Permissions**
2. Grant **all permissions** manually
3. Most important: **Usage Access** (Settings > Apps > Special access > Usage access > AppInsight > Allow)

## Step-by-Step Installation Process

### Method 1: Direct Install (Easiest)
1. **Download APK** to your phone
2. **Tap the APK file** in your file manager/downloads
3. **Allow installation** when prompted
4. **Open the app** and grant permissions

### Method 2: USB Install (Most Reliable)
1. **Enable Developer Options**:
   - Go to **Settings** > **About phone**
   - Tap **Build number** 7 times
   - Go back to **Settings** > **Developer options**
   - Enable **USB debugging**

2. **Connect phone to computer** via USB
3. **Copy APK to phone** storage
4. **Install using file manager** or ADB:
   ```bash
   adb install app-debug.apk
   ```

### Method 3: Build and Install Directly
If you have Android Studio:
```bash
cd android
./gradlew installDebug
```

## Device Requirements

- **Android 7.0+** (API level 24+)
- **50MB free space** minimum
- **ARM or x86 architecture** (most Android devices)

## Post-Installation Setup

1. **Open AppInsight**
2. **Grant Usage Access**:
   - Settings > Apps > Special access > Usage access
   - Find AppInsight > Toggle ON
3. **Grant other permissions** when prompted
4. **Restart the app** for full functionality

## Still Having Issues?

Try these advanced solutions:

### Clear Package Installer Cache
1. Settings > Apps > Package installer > Storage > Clear Cache

### Use Different Installation Method
- Try **APK Installer** app from Play Store
- Use **ES File Explorer** or **Solid Explorer**
- Install via **ADB** (developer method)

### Check APK Integrity
- Verify APK file size (should be 15-25MB)
- Re-download if file seems corrupted
- Try transferring via different method (email, USB, cloud)

### Device-Specific Issues
- **Samsung**: Disable **Smart Manager** app scanning
- **Xiaomi**: Enable **"Install via USB"** in Developer options
- **Huawei**: Allow installation in **"Phone Manager"**

## Getting Help

If none of these solutions work:
1. **Note your exact error message**
2. **Check your Android version** (Settings > About phone)
3. **Try on a different device** to isolate the issue
4. **Rebuild the APK** with different settings if needed

Your AppInsight app should install and work perfectly once these issues are resolved!
