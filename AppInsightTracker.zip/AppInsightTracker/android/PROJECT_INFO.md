
# AppInsight Android Studio Project

## Project Details

**Package Name:** `com.example.appinsight`
**App Name:** AppInsight
**Version:** 1.0 (versionCode: 1)
**Min SDK:** 24 (Android 7.0)
**Target SDK:** 34 (Android 14)
**Language:** Kotlin

## Project Structure

```
AppInsight/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/appinsight/
│   │   │   ├── MainActivity.kt                    # Main activity
│   │   │   └── plugins/
│   │   │       ├── UsageStatsManager.kt          # App usage tracking
│   │   │       ├── BatteryInfoManager.kt         # Battery monitoring
│   │   │       ├── StorageInfoManager.kt         # Storage analysis
│   │   │       └── InstalledAppsManager.kt       # Apps management
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml          # Main UI layout
│   │   │   ├── values/strings.xml                # App strings
│   │   │   ├── values/styles.xml                 # App themes
│   │   │   └── mipmap-*/                         # App icons
│   │   └── AndroidManifest.xml                   # App permissions & config
│   ├── build.gradle                              # App build configuration
│   └── proguard-rules.pro                        # ProGuard rules
├── gradle/                                       # Gradle wrapper
├── build.gradle                                  # Project build configuration
├── gradle.properties                             # Project properties
└── settings.gradle                               # Project settings
```

## Key Features Implemented

### 1. App Usage Statistics
- **File:** `plugins/UsageStatsManager.kt`
- **Functionality:** Tracks app usage time, last used timestamps
- **Permission:** `PACKAGE_USAGE_STATS`

### 2. Battery Monitoring
- **File:** `plugins/BatteryInfoManager.kt`
- **Functionality:** Battery level, temperature, voltage, charging status, health
- **Permission:** `BATTERY_STATS`

### 3. Storage Analysis
- **File:** `plugins/StorageInfoManager.kt`
- **Functionality:** Total/used/free storage breakdown
- **Permission:** None required

### 4. Installed Apps Management
- **File:** `plugins/InstalledAppsManager.kt`
- **Functionality:** List all installed apps with versions, sizes, install dates
- **Permission:** `QUERY_ALL_PACKAGES`

## Permissions Required

Add these to your AndroidManifest.xml:
```xml
<uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
<uses-permission android:name="android.permission.BATTERY_STATS" />
<uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

## How to Open in Android Studio

1. **Download and extract** the AppInsight-Android-Studio-Project.zip
2. **Open Android Studio**
3. **Click "Open an Existing Project"**
4. **Navigate to** the extracted project folder
5. **Select the root folder** (containing build.gradle)
6. **Wait for Gradle sync** to complete
7. **Build and run** on device or emulator

## Building APK

```bash
# Debug APK
./gradlew assembleDebug

# Release APK (unsigned)
./gradlew assembleRelease

# Install on connected device
./gradlew installDebug
```

## Keystore Information

**Note:** No existing keystore found. To create one for Play Store uploads:

```bash
keytool -genkey -v -keystore appinsight-release-key.keystore -alias appinsight -keyalg RSA -keysize 2048 -validity 10000
```

Then add to `app/build.gradle`:
```gradle
android {
    signingConfigs {
        release {
            storeFile file('path/to/appinsight-release-key.keystore')
            storePassword 'your-store-password'
            keyAlias 'appinsight'
            keyPassword 'your-key-password'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            // ... other config
        }
    }
}
```

## Dependencies Used

- **androidx.core:core-ktx** - Kotlin extensions
- **androidx.appcompat** - Backward compatibility
- **material** - Material Design components
- **androidx.lifecycle** - Lifecycle-aware components
- **androidx.work** - Background task processing

## Next Steps

1. **Customize the UI** in `activity_main.xml`
2. **Add more features** by extending the manager classes
3. **Implement data persistence** with Room database
4. **Add network features** for data synchronization
5. **Create release keystore** for Play Store publishing

## Support

This is a native Kotlin Android project with all AppInsight features implemented. The code is clean, well-structured, and ready for further development.
