
package com.example.appinsight;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.util.List;

@CapacitorPlugin(name = "InstalledApps")
public class InstalledAppsPlugin extends Plugin {
    
    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        try {
            PackageManager pm = getContext().getPackageManager();
            List<PackageInfo> packages = pm.getInstalledPackages(PackageManager.GET_META_DATA);
            
            JSArray appsArray = new JSArray();
            
            for (PackageInfo packageInfo : packages) {
                JSObject app = new JSObject();
                ApplicationInfo appInfo = packageInfo.applicationInfo;
                
                boolean isSystemApp = (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                
                app.put("appId", packageInfo.packageName);
                app.put("appName", pm.getApplicationLabel(appInfo).toString());
                app.put("versionName", packageInfo.versionName);
                app.put("versionCode", packageInfo.versionCode);
                app.put("isSystemApp", isSystemApp);
                app.put("installTime", packageInfo.firstInstallTime);
                app.put("updateTime", packageInfo.lastUpdateTime);
                
                try {
                    long appSize = getAppSize(packageInfo.applicationInfo.sourceDir);
                    app.put("appSize", appSize);
                } catch (Exception e) {
                    app.put("appSize", 0);
                }
                
                appsArray.put(app);
            }
            
            JSObject result = new JSObject();
            result.put("apps", appsArray);
            result.put("totalApps", packages.size());
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting installed apps: " + e.getMessage());
        }
    }
    
    private long getAppSize(String apkPath) {
        try {
            java.io.File file = new java.io.File(apkPath);
            return file.length();
        } catch (Exception e) {
            return 0;
        }
    }
}
