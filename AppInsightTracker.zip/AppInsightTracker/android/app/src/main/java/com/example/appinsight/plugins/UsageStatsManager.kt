
package com.example.appinsight.plugins

import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import java.util.*

data class AppUsageData(
    val appId: String,
    val appName: String,
    val usageTime: Long,
    val lastUsed: Long,
    val category: String = "Unknown"
)

class UsageStatsManager(private val context: Context) {
    
    private val usageStatsManager: UsageStatsManager by lazy {
        context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    }
    
    fun getAppUsageStats(): List<AppUsageData> {
        return try {
            val calendar = Calendar.getInstance()
            val endTime = calendar.timeInMillis
            calendar.add(Calendar.DAY_OF_YEAR, -7)
            val startTime = calendar.timeInMillis
            
            val usageStatsList = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, startTime, endTime
            )
            
            val packageManager = context.packageManager
            val appUsageList = mutableListOf<AppUsageData>()
            
            usageStatsList.sortByDescending { it.totalTimeInForeground }
            
            for (usageStats in usageStatsList) {
                if (usageStats.totalTimeInForeground > 0) {
                    try {
                        val appInfo = packageManager.getApplicationInfo(usageStats.packageName, 0)
                        val appName = packageManager.getApplicationLabel(appInfo).toString()
                        
                        appUsageList.add(
                            AppUsageData(
                                appId = usageStats.packageName,
                                appName = appName,
                                usageTime = usageStats.totalTimeInForeground / 1000 / 60, // Convert to minutes
                                lastUsed = usageStats.lastTimeUsed
                            )
                        )
                    } catch (e: PackageManager.NameNotFoundException) {
                        // App not found, skip
                    }
                }
            }
            
            appUsageList
        } catch (e: Exception) {
            emptyList()
        }
    }
}
