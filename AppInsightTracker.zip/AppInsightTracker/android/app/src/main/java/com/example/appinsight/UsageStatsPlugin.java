
package com.example.appinsight;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.Calendar;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

@CapacitorPlugin(name = "UsageStats")
public class UsageStatsPlugin extends Plugin {
    
    @PluginMethod
    public void getAppUsageStats(PluginCall call) {
        try {
            UsageStatsManager usageStatsManager = (UsageStatsManager) 
                getContext().getSystemService(Context.USAGE_STATS_SERVICE);
            
            Calendar calendar = Calendar.getInstance();
            long endTime = calendar.getTimeInMillis();
            calendar.add(Calendar.DAY_OF_YEAR, -7);
            long startTime = calendar.getTimeInMillis();
            
            List<UsageStats> usageStatsList = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, startTime, endTime);
            
            JSArray appsArray = new JSArray();
            PackageManager pm = getContext().getPackageManager();
            
            Collections.sort(usageStatsList, new Comparator<UsageStats>() {
                @Override
                public int compare(UsageStats a, UsageStats b) {
                    return Long.compare(b.getTotalTimeInForeground(), a.getTotalTimeInForeground());
                }
            });
            
            for (UsageStats usageStats : usageStatsList) {
                if (usageStats.getTotalTimeInForeground() > 0) {
                    JSObject app = new JSObject();
                    try {
                        ApplicationInfo appInfo = pm.getApplicationInfo(usageStats.getPackageName(), 0);
                        String appName = pm.getApplicationLabel(appInfo).toString();
                        
                        app.put("appId", usageStats.getPackageName());
                        app.put("appName", appName);
                        app.put("usageTime", usageStats.getTotalTimeInForeground() / 1000 / 60);
                        app.put("lastUsed", usageStats.getLastTimeUsed());
                        
                        appsArray.put(app);
                    } catch (PackageManager.NameNotFoundException e) {
                        // App not found, skip
                    }
                }
            }
            
            JSObject result = new JSObject();
            result.put("apps", appsArray);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting app usage stats: " + e.getMessage());
        }
    }
}
