
package com.example.appinsight.plugins

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import java.io.File

data class InstalledAppData(
    val appId: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val installTime: Long,
    val updateTime: Long,
    val appSize: Long
)

class InstalledAppsManager(private val context: Context) {
    
    fun getInstalledApps(): List<InstalledAppData> {
        return try {
            val packageManager = context.packageManager
            val packages = packageManager.getInstalledPackages(PackageManager.GET_META_DATA)
            
            packages.map { packageInfo ->
                val appInfo = packageInfo.applicationInfo
                val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                
                InstalledAppData(
                    appId = packageInfo.packageName,
                    appName = packageManager.getApplicationLabel(appInfo).toString(),
                    versionName = packageInfo.versionName ?: "Unknown",
                    versionCode = packageInfo.longVersionCode,
                    isSystemApp = isSystemApp,
                    installTime = packageInfo.firstInstallTime,
                    updateTime = packageInfo.lastUpdateTime,
                    appSize = getAppSize(appInfo.sourceDir)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    private fun getAppSize(apkPath: String): Long {
        return try {
            File(apkPath).length()
        } catch (e: Exception) {
            0L
        }
    }
}
