
package com.example.appinsight.plugins

import android.content.Context
import android.os.Environment
import android.os.StatFs

data class StorageBreakdown(
    val totalStorage: Long,
    val usedStorage: Long,
    val freeStorage: Long,
    val usedPercentage: Int
)

class StorageInfoManager(private val context: Context) {
    
    fun getStorageBreakdown(): StorageBreakdown? {
        return try {
            // Internal storage
            val internalStat = StatFs(Environment.getDataDirectory().path)
            val internalTotal = internalStat.totalBytes
            val internalFree = internalStat.availableBytes
            val internalUsed = internalTotal - internalFree
            
            StorageBreakdown(
                totalStorage = internalTotal,
                usedStorage = internalUsed,
                freeStorage = internalFree,
                usedPercentage = Math.round((internalUsed * 100.0f) / internalTotal)
            )
        } catch (e: Exception) {
            null
        }
    }
}
