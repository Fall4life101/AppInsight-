
package com.example.appinsight;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

@CapacitorPlugin(name = "BatteryInfo")
public class BatteryInfoPlugin extends Plugin {
    
    @PluginMethod
    public void getBatteryDetails(PluginCall call) {
        try {
            IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = getContext().registerReceiver(null, intentFilter);
            
            JSObject result = new JSObject();
            
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                String technology = batteryStatus.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
                
                result.put("level", Math.round((level * 100.0f) / scale));
                result.put("temperature", temperature / 10.0);
                result.put("voltage", voltage / 1000.0);
                result.put("isCharging", status == BatteryManager.BATTERY_STATUS_CHARGING);
                result.put("technology", technology != null ? technology : "Unknown");
                
                int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
                String healthString = "Unknown";
                switch (health) {
                    case BatteryManager.BATTERY_HEALTH_GOOD:
                        healthString = "Good";
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                        healthString = "Overheat";
                        break;
                    case BatteryManager.BATTERY_HEALTH_DEAD:
                        healthString = "Dead";
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                        healthString = "Over Voltage";
                        break;
                    case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                        healthString = "Unspecified Failure";
                        break;
                    case BatteryManager.BATTERY_HEALTH_COLD:
                        healthString = "Cold";
                        break;
                }
                result.put("health", healthString);
            }
            
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting battery details: " + e.getMessage());
        }
    }
}
