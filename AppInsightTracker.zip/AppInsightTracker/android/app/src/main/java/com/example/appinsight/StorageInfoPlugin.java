
package com.example.appinsight;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.os.StatFs;
import android.os.Environment;

@CapacitorPlugin(name = "StorageInfo")
public class StorageInfoPlugin extends Plugin {
    
    @PluginMethod
    public void getStorageBreakdown(PluginCall call) {
        try {
            JSObject result = new JSObject();
            
            // Internal storage
            StatFs internalStat = new StatFs(Environment.getDataDirectory().getPath());
            long internalTotal = internalStat.getTotalBytes();
            long internalFree = internalStat.getAvailableBytes();
            long internalUsed = internalTotal - internalFree;
            
            result.put("totalStorage", internalTotal);
            result.put("usedStorage", internalUsed);
            result.put("freeStorage", internalFree);
            result.put("usedPercentage", Math.round((internalUsed * 100.0f) / internalTotal));
            
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting storage breakdown: " + e.getMessage());
        }
    }
}
