
package com.example.appinsight.plugins

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

data class BatteryDetails(
    val level: Int,
    val temperature: Double,
    val voltage: Double,
    val isCharging: Boolean,
    val technology: String,
    val health: String
)

class BatteryInfoManager(private val context: Context) {
    
    fun getBatteryDetails(): BatteryDetails? {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            
            batteryStatus?.let { status ->
                val level = status.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = status.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val temperature = status.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                val voltage = status.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                val chargingStatus = status.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val technology = status.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown"
                val health = status.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
                
                BatteryDetails(
                    level = Math.round((level * 100.0f) / scale),
                    temperature = temperature / 10.0,
                    voltage = voltage / 1000.0,
                    isCharging = chargingStatus == BatteryManager.BATTERY_STATUS_CHARGING,
                    technology = technology,
                    health = getHealthString(health)
                )
            }
        } catch (e: Exception) {
            null
        }
    }
    
    private fun getHealthString(health: Int): String {
        return when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Unspecified Failure"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }
    }
}
