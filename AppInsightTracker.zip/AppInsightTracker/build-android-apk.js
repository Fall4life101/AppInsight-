
#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Starting AppInsight APK Build Process...\n');

function runCommand(command, description) {
  console.log(`📦 ${description}...`);
  try {
    execSync(command, { stdio: 'inherit', cwd: process.cwd() });
    console.log(`✅ ${description} completed\n`);
    return true;
  } catch (error) {
    console.log(`❌ ${description} failed: ${error.message}\n`);
    return false;
  }
}

function checkFile(filePath, description) {
  if (fs.existsSync(filePath)) {
    const stats = fs.statSync(filePath);
    console.log(`✅ ${description}: ${(stats.size / 1024 / 1024).toFixed(2)}MB`);
    return true;
  } else {
    console.log(`❌ ${description} not found`);
    return false;
  }
}

// Step 1: Clean previous builds
console.log('🧹 Cleaning previous builds...');
if (fs.existsSync('android/app/build')) {
  fs.rmSync('android/app/build', { recursive: true, force: true });
}

// Step 2: Build web app
if (!runCommand('npm run build', 'Building web application')) {
  process.exit(1);
}

// Step 3: Sync with Android
if (!runCommand('npx cap sync android', 'Syncing with Android platform')) {
  process.exit(1);
}

// Step 4: Make gradlew executable
if (!runCommand('chmod +x android/gradlew', 'Making Gradle wrapper executable')) {
  process.exit(1);
}

// Step 5: Try different build methods
const buildMethods = [
  {
    command: 'cd android && ./gradlew assembleDebug --no-daemon --warning-mode all',
    description: 'Building APK with Gradle (method 1)'
  },
  {
    command: 'cd android && ./gradlew build --no-daemon',
    description: 'Building APK with Gradle (method 2)'
  },
  {
    command: 'cd android && ./gradlew assembleDebug --stacktrace --info',
    description: 'Building APK with detailed output'
  }
];

let buildSuccessful = false;
for (const method of buildMethods) {
  if (runCommand(method.command, method.description)) {
    buildSuccessful = true;
    break;
  }
}

if (!buildSuccessful) {
  console.log('❌ All build methods failed. Trying alternative approach...');
  
  // Alternative: Use Capacitor build
  if (runCommand('npx cap build android', 'Building with Capacitor CLI')) {
    buildSuccessful = true;
  }
}

// Step 6: Check for APK files
console.log('\n🔍 Searching for APK files...');
const apkPaths = [
  'android/app/build/outputs/apk/debug/app-debug.apk',
  'android/app/build/outputs/apk/release/app-release.apk',
  'android/app/build/outputs/apk/app-debug.apk'
];

let apkFound = false;
for (const apkPath of apkPaths) {
  if (checkFile(apkPath, `APK at ${apkPath}`)) {
    console.log(`\n🎉 SUCCESS! Your APK is ready at: ${apkPath}`);
    console.log(`📱 Transfer this file to your Android device and install it.`);
    apkFound = true;
    break;
  }
}

if (!apkFound) {
  console.log('\n❌ No APK file found. Check the build output above for errors.');
  
  // List all files in build directory for debugging
  const buildDir = 'android/app/build';
  if (fs.existsSync(buildDir)) {
    console.log('\n📂 Files in build directory:');
    execSync(`find ${buildDir} -name "*.apk" -o -name "*.aab"`, { stdio: 'inherit' });
  }
}

console.log('\n🏁 Build process completed.');
