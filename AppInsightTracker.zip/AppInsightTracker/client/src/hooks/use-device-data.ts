import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { deviceMonitor } from "@/lib/real-time-monitor";
import type { DeviceInfo } from "@/lib/device-info";

export interface DeviceStats {
  battery: {
    id: number;
    level: number;
    isCharging: boolean;
    temperature: number;
    timestamp: string;
    userId: number;
  } | null;
  storage: {
    id: number;
    totalSpace: number;
    usedSpace: number;
    freeSpace: number;
    userId: number;
  } | null;
  appUsage: {
    totalApps: number;
    totalScreenTime: number;
    apps: Array<{
      id: number;
      appName: string;
      packageName: string;
      timeUsed: number;
      lastUsed: string;
      userId: number;
    }>;
  };
  overview: {
    screenTime: number;
    appUsage: number;
    storageUsed: number;
    storagePercentage: number;
    batteryLevel: number;
    batteryRemainingTime: string;
  };
}

export interface AppHistoryItem {
  id: string;
  name: string;
  icon: string;
  color: string;
  date: string;
  time: string;
  size: string;
  status: "installed" | "deleted";
}

// Hook to get real device statistics
export function useDeviceStats() {
  const queryClient = useQueryClient();

  // Set up real-time monitoring
  useEffect(() => {
    const handleDeviceUpdate = (deviceInfo: DeviceInfo) => {
      // Invalidate queries when real device data updates
      queryClient.invalidateQueries({ queryKey: ["/api/device-stats"] });
    };

    deviceMonitor.addListener(handleDeviceUpdate);
    deviceMonitor.startMonitoring();

    return () => {
      deviceMonitor.removeListener(handleDeviceUpdate);
    };
  }, [queryClient]);

  return useQuery<DeviceStats>({
    queryKey: ["/api/device-stats"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });
}

// Hook to get app history data
export function useAppHistory() {
  return useQuery<AppHistoryItem[]>({
    queryKey: ["/api/app-history"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
}

// Hook to simulate app usage data (for demo purposes)
export function useSimulateAppUsage() {
  const queryClient = useQueryClient();

  const simulateData = async () => {
    try {
      const response = await fetch("/api/simulate-app-usage", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to simulate app usage data");
      }

      // Invalidate device stats to refresh with new data
      queryClient.invalidateQueries({ queryKey: ["/api/device-stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/app-history"] });

      return response.json();
    } catch (error) {
      console.error("Error simulating app usage:", error);
      throw error;
    }
  };

  return { simulateData };
}

// Transform device stats for dashboard components
export function transformDeviceStatsForDashboard(stats: DeviceStats | undefined) {
  if (!stats) {
    return {
      statsOverview: {
        screenTime: 0,
        appUsage: 0,
        storageUsed: 0,
        storagePercentage: 0,
        batteryLevel: 0,
        batteryRemainingTime: "Unknown",
      },
      batteryData: {
        level: 0,
        status: "Unknown",
        remainingTime: "Unknown",
        temperature: "Unknown",
      },
      mostUsedApps: [],
      storageData: [],
      totalStorage: {
        total: 0,
        used: 0,
        free: 0,
      },
    };
  }

  // Transform app usage for most used apps
  const mostUsedApps = stats.appUsage.apps
    .sort((a, b) => b.timeUsed - a.timeUsed)
    .slice(0, 5)
    .map((app, index) => ({
      id: app.id.toString(),
      name: app.appName,
      icon: getAppIcon(app.appName),
      color: getAppColor(app.appName),
      timeSpent: Math.round(app.timeUsed / 60), // Convert to minutes
      percentage: Math.round((app.timeUsed / Math.max(stats.appUsage.apps[0]?.timeUsed || 1, 1)) * 100),
    }));

  // Transform storage data for pie chart
  const storageData = stats.storage ? [
    {
      id: "1",
      name: "Used Space",
      color: "#4285F4",
      size: stats.storage.usedSpace,
      percentage: (stats.storage.usedSpace / stats.storage.totalSpace) * 100,
    },
    {
      id: "2",
      name: "Free Space",
      color: "#34A853",
      size: stats.storage.freeSpace,
      percentage: (stats.storage.freeSpace / stats.storage.totalSpace) * 100,
    },
  ] : [];

  return {
    statsOverview: stats.overview,
    batteryData: {
      level: stats.battery?.level || 0,
      status: stats.battery?.isCharging ? "Charging" : "Discharging",
      remainingTime: stats.overview.batteryRemainingTime,
      temperature: stats.battery?.temperature ? `${stats.battery.temperature}°C` : "Unknown",
    },
    mostUsedApps,
    storageData,
    totalStorage: stats.storage ? {
      total: Math.round(stats.storage.totalSpace / (1024 * 1024 * 1024)), // Convert to GB
      used: Math.round(stats.storage.usedSpace / (1024 * 1024 * 1024)),
      free: Math.round(stats.storage.freeSpace / (1024 * 1024 * 1024)),
    } : { total: 0, used: 0, free: 0 },
  };
}

// Helper functions (duplicated from backend for consistency)
function getAppIcon(appName: string): string {
  const icons: { [key: string]: string } = {
    "Chrome": "🌐",
    "Gmail": "📧",
    "YouTube": "📺",
    "WhatsApp": "💬",
    "Instagram": "📷",
    "Spotify": "🎵",
    "Maps": "🗺️",
    "Photos": "📸",
    "Calculator": "🧮",
    "Settings": "⚙️",
  };
  return icons[appName] || "📱";
}

function getAppColor(appName: string): string {
  const colors: { [key: string]: string } = {
    "Chrome": "#4285F4",
    "Gmail": "#D44638",
    "YouTube": "#FF0000",
    "WhatsApp": "#25D366",
    "Instagram": "#E1306C",
    "Spotify": "#1DB954",
    "Maps": "#4285F4",
    "Photos": "#4285F4",
    "Calculator": "#9AA0A6",
    "Settings": "#9AA0A6",
  };
  return colors[appName] || "#9AA0A6";
}