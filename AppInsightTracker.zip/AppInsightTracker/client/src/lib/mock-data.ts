export type AppUsageData = {
  id: string;
  name: string;
  icon: string;
  color: string;
  timeSpent: number; // in minutes
  percentage: number;
};

export type AppUsageTimelineData = {
  hour: string;
  socialMedia: number;
  productivity: number;
  entertainment: number;
  other: number;
};

export type StorageData = {
  id: string;
  name: string;
  color: string;
  size: number; // in bytes
  percentage: number;
};

export type BatteryData = {
  level: number;
  status: string;
  remainingTime: string;
  temperature: string;
};

export type BatteryConsumptionData = {
  id: string;
  name: string;
  icon: string;
  color: string;
  percentage: number;
};

// Most used apps data
export const mostUsedApps: AppUsageData[] = [
  {
    id: "1",
    name: "Facebook",
    icon: "facebook",
    color: "#1877F2",
    timeSpent: 83, // 1h 23m
    percentage: 80,
  },
  {
    id: "2",
    name: "Instagram",
    icon: "instagram",
    color: "#E1306C",
    timeSpent: 52,
    percentage: 60,
  },
  {
    id: "3",
    name: "Twitter",
    icon: "twitter",
    color: "#00ACEE",
    timeSpent: 45,
    percentage: 50,
  },
  {
    id: "4",
    name: "WhatsApp",
    icon: "whatsapp",
    color: "#25D366",
    timeSpent: 38,
    percentage: 40,
  },
  {
    id: "5",
    name: "Excel",
    icon: "file-spreadsheet",
    color: "#2ab200",
    timeSpent: 35,
    percentage: 35,
  },
  {
    id: "6",
    name: "YouTube",
    icon: "youtube",
    color: "#FF0000",
    timeSpent: 30,
    percentage: 30,
  },
];

// App usage timeline data
export const appUsageTimeline: AppUsageTimelineData[] = [
  { hour: "6AM", socialMedia: 30, productivity: 15, entertainment: 45, other: 10 },
  { hour: "8AM", socialMedia: 40, productivity: 25, entertainment: 25, other: 10 },
  { hour: "10AM", socialMedia: 20, productivity: 60, entertainment: 10, other: 10 },
  { hour: "12PM", socialMedia: 15, productivity: 70, entertainment: 5, other: 10 },
  { hour: "2PM", socialMedia: 35, productivity: 30, entertainment: 25, other: 10 },
  { hour: "4PM", socialMedia: 25, productivity: 50, entertainment: 15, other: 10 },
  { hour: "6PM", socialMedia: 55, productivity: 15, entertainment: 20, other: 10 },
  { hour: "8PM", socialMedia: 45, productivity: 5, entertainment: 40, other: 10 },
];

// Storage data
export const storageData: StorageData[] = [
  {
    id: "1",
    name: "Apps",
    color: "#4A90E2",
    size: 35000000000, // 32.6 GB
    percentage: 50.7,
  },
  {
    id: "2",
    name: "Photos",
    color: "#50C878",
    size: 19800000000, // 18.4 GB
    percentage: 28.6,
  },
  {
    id: "3",
    name: "Videos",
    color: "#FF6B6B",
    size: 10500000000, // 9.8 GB
    percentage: 15.2,
  },
  {
    id: "4",
    name: "Other",
    color: "#F59E0B",
    size: 3800000000, // 3.5 GB
    percentage: 5.5,
  },
];

// Total storage usage
export const totalStorage = {
  total: 128000000000, // 128 GB
  used: 69100000000, // 64.3 GB
  free: 58900000000, // 58.9 GB
  percentageUsed: 54, // 54%
};

// Battery data
export const batteryData: BatteryData = {
  level: 73,
  status: "Discharging",
  remainingTime: "5 hours 12 minutes",
  temperature: "28°C (Normal)",
};

// Battery consumption by app
export const batteryConsumptionData: BatteryConsumptionData[] = [
  {
    id: "1",
    name: "Facebook",
    icon: "facebook",
    color: "#1877F2",
    percentage: 18,
  },
  {
    id: "2",
    name: "Instagram",
    icon: "instagram",
    color: "#E1306C",
    percentage: 14,
  },
  {
    id: "3",
    name: "YouTube",
    icon: "youtube",
    color: "#FF0000",
    percentage: 12,
  },
  {
    id: "4",
    name: "WhatsApp",
    icon: "whatsapp",
    color: "#25D366",
    percentage: 9,
  },
  {
    id: "5",
    name: "Discord",
    icon: "discord",
    color: "#5865F2",
    percentage: 8,
  },
  {
    id: "6",
    name: "Calendar",
    icon: "calendar",
    color: "#007AFF",
    percentage: 6,
  },
];

// Stats overview
export const statsOverview = {
  appUsageTime: 263, // 4h 23m in minutes
  appsOpened: 37,
  storageUsed: 69100000000, // 64.3 GB
  storageTotal: 128000000000, // 128 GB
  batteryLevel: 73,
  batteryRemainingTime: "5 hours",
};
