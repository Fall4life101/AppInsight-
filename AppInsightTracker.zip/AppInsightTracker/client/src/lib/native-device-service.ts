import { Capacitor } from '@capacitor/core';

// Extended device info interface for native features
export interface NativeDeviceInfo {
  // App usage statistics (requires native implementation)
  appUsage?: {
    appId: string;
    appName: string;
    usageTime: number; // in minutes
    lastUsed: Date;
    category: string;
    batteryUsage?: number; // percentage
  }[];
  
  // System storage breakdown (requires native implementation)
  systemStorage?: {
    totalStorage: number;
    usedStorage: number;
    freeStorage: number;
    appStorage: number;
    systemStorage: number;
    mediaStorage: number;
    otherStorage: number;
  };
  
  // Individual app battery consumption (requires native implementation)
  appBatteryUsage?: {
    appId: string;
    appName: string;
    batteryPercentage: number;
    foregroundTime: number;
    backgroundTime: number;
  }[];
  
  // Installed apps list (requires native implementation)
  installedApps?: {
    appId: string;
    appName: string;
    packageName: string;
    version: string;
    installDate: Date;
    lastUpdated: Date;
    category: string;
    icon?: string;
    size: number;
  }[];
  
  // Enhanced battery info (from native APIs)
  batteryInfo?: {
    level: number;
    isCharging: boolean;
    health: string;
    temperature: number;
    voltage: number;
    technology: string;
    chargingTime?: number;
    dischargingTime?: number;
  };
  
  // System information (from native APIs)
  systemInfo?: {
    deviceModel: string;
    manufacturer: string;
    operatingSystem: string;
    osVersion: string;
    totalMemory: number;
    availableMemory: number;
    cpuInfo: string;
    architecture: string;
  };
}

class NativeDeviceService {
  private isNative: boolean;
  private hasPermissions: boolean = false;

  constructor() {
    this.isNative = Capacitor.isNativePlatform();
    console.log('Native device service initialized:', { isNative: this.isNative });
  }

  public isRunningNatively(): boolean {
    return this.isNative;
  }

  public async requestPermissions(): Promise<boolean> {
    if (!this.isNative) {
      console.log('Not running natively, permissions not needed');
      return false;
    }

    try {
      // Request usage access permission (Android-specific)
      if (Capacitor.getPlatform() === 'android') {
        // This would need to be implemented in native code
        console.log('Requesting Android usage access permission');
        // For now, we'll simulate the permission request
        this.hasPermissions = true;
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error requesting permissions:', error);
      return false;
    }
  }

  public async getDetailedAppUsage(): Promise<NativeDeviceInfo['appUsage']> {
    if (!this.isNative) {
      console.log('Cannot get detailed app usage: not native or no permissions');
      return this.getMockAppUsage();
    }

    try {
      // Call native UsageStats plugin
      const result = await (window as any).UsageStats.getAppUsageStats();
      
      if (result && result.apps) {
        return result.apps.map((app: any) => ({
          appId: app.appId,
          appName: app.appName,
          usageTime: app.usageTime,
          lastUsed: new Date(app.lastUsed),
          category: 'Unknown', // Category would need additional mapping
          batteryUsage: Math.floor(Math.random() * 20) + 5, // Mock battery usage for now
        }));
      }
      
      return this.getMockAppUsage();
    } catch (error) {
      console.error('Error getting detailed app usage:', error);
      return this.getMockAppUsage();
    }
  }

  public async getSystemStorageBreakdown(): Promise<NativeDeviceInfo['systemStorage']> {
    if (!this.isNative) {
      console.log('Cannot get system storage breakdown: not native');
      return this.getMockSystemStorage();
    }

    try {
      // Call native StorageInfo plugin
      const result = await (window as any).StorageInfo.getStorageBreakdown();
      
      if (result) {
        return {
          totalStorage: result.totalStorage,
          usedStorage: result.usedStorage,
          freeStorage: result.freeStorage,
          appStorage: result.usedStorage * 0.5, // Approximate app storage
          systemStorage: result.usedStorage * 0.3, // Approximate system storage
          mediaStorage: result.usedStorage * 0.15, // Approximate media storage
          otherStorage: result.usedStorage * 0.05, // Approximate other storage
        };
      }
      
      return this.getMockSystemStorage();
    } catch (error) {
      console.error('Error getting system storage:', error);
      return this.getMockSystemStorage();
    }
  }

  public async getAppBatteryUsage(): Promise<NativeDeviceInfo['appBatteryUsage']> {
    if (!this.isNative) {
      console.log('Cannot get app battery usage: not native');
      return this.getMockAppBatteryUsage();
    }

    try {
      // This would call native APIs to get real app battery usage
      console.log('Getting app battery usage from native APIs');
      
      // For now, return mock data
      return this.getMockAppBatteryUsage();
    } catch (error) {
      console.error('Error getting app battery usage:', error);
      return this.getMockAppBatteryUsage();
    }
  }

  public async getInstalledApps(): Promise<NativeDeviceInfo['installedApps']> {
    if (!this.isNative) {
      console.log('Cannot get installed apps: not native');
      return this.getMockInstalledApps();
    }

    try {
      // Call native InstalledApps plugin
      const result = await (window as any).InstalledApps.getInstalledApps();
      
      if (result && result.apps) {
        return result.apps.map((app: any) => ({
          appId: app.appId,
          appName: app.appName,
          packageName: app.appId,
          version: app.versionName,
          installDate: new Date(app.installTime),
          lastUpdated: new Date(app.updateTime),
          category: app.isSystemApp ? 'System' : 'User',
          size: app.appSize,
        }));
      }
      
      return this.getMockInstalledApps();
    } catch (error) {
      console.error('Error getting installed apps:', error);
      return this.getMockInstalledApps();
    }
  }

  public async getEnhancedBatteryInfo(): Promise<NativeDeviceInfo['batteryInfo']> {
    if (!this.isNative) {
      console.log('Cannot get enhanced battery info: not native');
      return undefined;
    }

    try {
      // Call native BatteryInfo plugin
      const result = await (window as any).BatteryInfo.getBatteryDetails();
      
      if (result) {
        return {
          level: result.level,
          isCharging: result.isCharging,
          health: result.health,
          temperature: result.temperature,
          voltage: result.voltage,
          technology: result.technology,
          dischargingTime: result.dischargingTime,
          chargingTime: result.chargingTime,
        };
      }
      
      return undefined;
    } catch (error) {
      console.error('Error getting enhanced battery info:', error);
      return undefined;
    }
  }

  public async getSystemInfo(): Promise<NativeDeviceInfo['systemInfo']> {
    if (!this.isNative) {
      console.log('Cannot get system info: not native');
      return undefined;
    }

    try {
      // This would call native APIs to get real system information
      console.log('Getting system info from native APIs');
      
      // For now, return mock data
      return {
        deviceModel: 'Pixel 7',
        manufacturer: 'Google',
        operatingSystem: 'Android',
        osVersion: '14.0',
        totalMemory: 8 * 1024 * 1024 * 1024, // 8GB
        availableMemory: 3.2 * 1024 * 1024 * 1024, // 3.2GB
        cpuInfo: 'Google Tensor G2',
        architecture: 'arm64-v8a',
      };
    } catch (error) {
      console.error('Error getting system info:', error);
      return undefined;
    }
  }

  // Mock data methods for web version
  private getMockAppUsage(): NativeDeviceInfo['appUsage'] {
    return [
      {
        appId: 'com.chrome.beta',
        appName: 'Chrome Beta',
        usageTime: 180,
        lastUsed: new Date(Date.now() - 2 * 60 * 1000),
        category: 'Browser',
        batteryUsage: 15,
      },
      {
        appId: 'com.whatsapp',
        appName: 'WhatsApp',
        usageTime: 95,
        lastUsed: new Date(Date.now() - 10 * 60 * 1000),
        category: 'Communication',
        batteryUsage: 8,
      },
      {
        appId: 'com.spotify.music',
        appName: 'Spotify',
        usageTime: 240,
        lastUsed: new Date(Date.now() - 30 * 60 * 1000),
        category: 'Music',
        batteryUsage: 12,
      },
    ];
  }

  private getMockSystemStorage(): NativeDeviceInfo['systemStorage'] {
    const totalStorage = 128 * 1024 * 1024 * 1024; // 128GB
    return {
      totalStorage,
      usedStorage: 89 * 1024 * 1024 * 1024, // 89GB
      freeStorage: 39 * 1024 * 1024 * 1024, // 39GB
      appStorage: 45 * 1024 * 1024 * 1024, // 45GB
      systemStorage: 18 * 1024 * 1024 * 1024, // 18GB
      mediaStorage: 22 * 1024 * 1024 * 1024, // 22GB
      otherStorage: 4 * 1024 * 1024 * 1024, // 4GB
    };
  }

  private getMockAppBatteryUsage(): NativeDeviceInfo['appBatteryUsage'] {
    return [
      {
        appId: 'com.chrome.beta',
        appName: 'Chrome Beta',
        batteryPercentage: 15,
        foregroundTime: 180,
        backgroundTime: 25,
      },
      {
        appId: 'com.spotify.music',
        appName: 'Spotify',
        batteryPercentage: 12,
        foregroundTime: 120,
        backgroundTime: 180,
      },
      {
        appId: 'com.whatsapp',
        appName: 'WhatsApp',
        batteryPercentage: 8,
        foregroundTime: 60,
        backgroundTime: 95,
      },
    ];
  }

  private getMockInstalledApps(): NativeDeviceInfo['installedApps'] {
    return [
      {
        appId: 'com.chrome.beta',
        appName: 'Chrome Beta',
        packageName: 'com.chrome.beta',
        version: '121.0.6167.144',
        installDate: new Date('2024-01-15'),
        lastUpdated: new Date('2024-07-10'),
        category: 'Browser',
        size: 150 * 1024 * 1024, // 150MB
      },
      {
        appId: 'com.whatsapp',
        appName: 'WhatsApp',
        packageName: 'com.whatsapp',
        version: '2.24.15.76',
        installDate: new Date('2023-12-01'),
        lastUpdated: new Date('2024-07-15'),
        category: 'Communication',
        size: 95 * 1024 * 1024, // 95MB
      },
      {
        appId: 'com.spotify.music',
        appName: 'Spotify',
        packageName: 'com.spotify.music',
        version: '8.9.68.488',
        installDate: new Date('2024-02-20'),
        lastUpdated: new Date('2024-07-12'),
        category: 'Music',
        size: 180 * 1024 * 1024, // 180MB
      },
    ];
  }
}

export const nativeDeviceService = new NativeDeviceService();
export default nativeDeviceService;