// Real device information collection for web applications
export interface DeviceInfo {
  battery: BatteryInfo;
  storage: StorageInfo;
  network: NetworkInfo;
  screen: ScreenInfo;
  system: SystemInfo;
}

export interface BatteryInfo {
  level: number;
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
  supported: boolean;
}

export interface StorageInfo {
  quota: number;
  usage: number;
  available: number;
  supported: boolean;
}

export interface NetworkInfo {
  effectiveType: string;
  downlink: number;
  rtt: number;
  saveData: boolean;
  supported: boolean;
}

export interface ScreenInfo {
  width: number;
  height: number;
  colorDepth: number;
  pixelDepth: number;
  orientation: string;
}

export interface SystemInfo {
  userAgent: string;
  platform: string;
  language: string;
  cookieEnabled: boolean;
  onLine: boolean;
  memoryInfo?: {
    totalJSHeapSize: number;
    usedJSHeapSize: number;
    jsHeapSizeLimit: number;
  };
}

// Real battery information using Battery API
export async function getBatteryInfo(): Promise<BatteryInfo> {
  try {
    // Check if Battery API is supported
    if ('getBattery' in navigator) {
      const battery = await (navigator as any).getBattery();
      return {
        level: Math.round(battery.level * 100),
        charging: battery.charging,
        chargingTime: battery.chargingTime,
        dischargingTime: battery.dischargingTime,
        supported: true
      };
    } else {
      return {
        level: 0,
        charging: false,
        chargingTime: Infinity,
        dischargingTime: Infinity,
        supported: false
      };
    }
  } catch (error) {
    console.warn('Battery API not available:', error);
    return {
      level: 0,
      charging: false,
      chargingTime: Infinity,
      dischargingTime: Infinity,
      supported: false
    };
  }
}

// Real storage information using StorageManager API
export async function getStorageInfo(): Promise<StorageInfo> {
  try {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      return {
        quota: estimate.quota || 0,
        usage: estimate.usage || 0,
        available: (estimate.quota || 0) - (estimate.usage || 0),
        supported: true
      };
    } else {
      return {
        quota: 0,
        usage: 0,
        available: 0,
        supported: false
      };
    }
  } catch (error) {
    console.warn('Storage API not available:', error);
    return {
      quota: 0,
      usage: 0,
      available: 0,
      supported: false
    };
  }
}

// Real network information using Network Information API
export function getNetworkInfo(): NetworkInfo {
  try {
    const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
    
    if (connection) {
      return {
        effectiveType: connection.effectiveType || 'unknown',
        downlink: connection.downlink || 0,
        rtt: connection.rtt || 0,
        saveData: connection.saveData || false,
        supported: true
      };
    } else {
      return {
        effectiveType: 'unknown',
        downlink: 0,
        rtt: 0,
        saveData: false,
        supported: false
      };
    }
  } catch (error) {
    console.warn('Network Information API not available:', error);
    return {
      effectiveType: 'unknown',
      downlink: 0,
      rtt: 0,
      saveData: false,
      supported: false
    };
  }
}

// Real screen information
export function getScreenInfo(): ScreenInfo {
  return {
    width: screen.width,
    height: screen.height,
    colorDepth: screen.colorDepth,
    pixelDepth: screen.pixelDepth,
    orientation: screen.orientation?.type || 'unknown'
  };
}

// Real system information
export function getSystemInfo(): SystemInfo {
  const systemInfo: SystemInfo = {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    cookieEnabled: navigator.cookieEnabled,
    onLine: navigator.onLine
  };

  // Add memory info if available (Chrome only)
  if ((performance as any).memory) {
    systemInfo.memoryInfo = {
      totalJSHeapSize: (performance as any).memory.totalJSHeapSize,
      usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
      jsHeapSizeLimit: (performance as any).memory.jsHeapSizeLimit
    };
  }

  return systemInfo;
}

// Collect all real device information
export async function collectDeviceInfo(): Promise<DeviceInfo> {
  const [battery, storage] = await Promise.all([
    getBatteryInfo(),
    getStorageInfo()
  ]);

  return {
    battery,
    storage,
    network: getNetworkInfo(),
    screen: getScreenInfo(),
    system: getSystemInfo()
  };
}

// Format bytes to human readable format
export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Format time remaining
export function formatTimeRemaining(seconds: number): string {
  if (seconds === Infinity || seconds < 0) return 'Unknown';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  } else {
    return `${minutes}m`;
  }
}

// Format duration in seconds to human readable format
export function formatDuration(seconds: number): string {
  if (seconds < 60) {
    return `${Math.round(seconds)}s`;
  } else if (seconds < 3600) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.round(seconds % 60);
    if (remainingSeconds === 0) {
      return `${minutes}m`;
    }
    return `${minutes}m ${remainingSeconds}s`;
  } else {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (minutes === 0) {
      return `${hours}h`;
    }
    return `${hours}h ${minutes}m`;
  }
}

// Format time ago
export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSeconds < 60) {
    return 'just now';
  } else if (diffMinutes < 60) {
    return `${diffMinutes}m ago`;
  } else if (diffHours < 24) {
    return `${diffHours}h ago`;
  } else if (diffDays < 7) {
    return `${diffDays}d ago`;
  } else {
    return date.toLocaleDateString();
  }
}