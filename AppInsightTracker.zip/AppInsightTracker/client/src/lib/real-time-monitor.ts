import { collectDeviceInfo, DeviceInfo } from './device-info';

export class RealTimeMonitor {
  private static instance: RealTimeMonitor;
  private isMonitoring: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;
  private listeners: Array<(data: DeviceInfo) => void> = [];
  private lastData: DeviceInfo | null = null;
  private monitoringInterval: number = 5000; // 5 seconds

  private constructor() {}

  static getInstance(): RealTimeMonitor {
    if (!RealTimeMonitor.instance) {
      RealTimeMonitor.instance = new RealTimeMonitor();
    }
    return RealTimeMonitor.instance;
  }

  // Start monitoring device information
  async startMonitoring(): Promise<void> {
    if (this.isMonitoring) return;

    this.isMonitoring = true;
    
    // Collect initial data
    await this.collectAndNotify();
    
    // Set up interval for continuous monitoring
    this.intervalId = setInterval(async () => {
      await this.collectAndNotify();
    }, this.monitoringInterval);

    console.log('Real-time monitoring started');
  }

  // Stop monitoring
  stopMonitoring(): void {
    if (!this.isMonitoring) return;

    this.isMonitoring = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    console.log('Real-time monitoring stopped');
  }

  // Add listener for device data updates
  addListener(callback: (data: DeviceInfo) => void): void {
    this.listeners.push(callback);
    
    // If we have cached data, immediately notify the new listener
    if (this.lastData) {
      callback(this.lastData);
    }
  }

  // Remove listener
  removeListener(callback: (data: DeviceInfo) => void): void {
    this.listeners = this.listeners.filter(listener => listener !== callback);
  }

  // Get the last collected data
  getLastData(): DeviceInfo | null {
    return this.lastData;
  }

  // Set monitoring interval
  setMonitoringInterval(interval: number): void {
    this.monitoringInterval = interval;
    
    // Restart monitoring with new interval if currently monitoring
    if (this.isMonitoring) {
      this.stopMonitoring();
      this.startMonitoring();
    }
  }

  // Collect data and notify listeners
  private async collectAndNotify(): Promise<void> {
    try {
      const deviceInfo = await collectDeviceInfo();
      this.lastData = deviceInfo;
      
      // Notify all listeners
      this.listeners.forEach(listener => {
        try {
          listener(deviceInfo);
        } catch (error) {
          console.error('Error in listener callback:', error);
        }
      });

      // Send data to backend for storage
      await this.sendToBackend(deviceInfo);
    } catch (error) {
      console.error('Error collecting device info:', error);
    }
  }

  // Send device data to backend
  private async sendToBackend(deviceInfo: DeviceInfo): Promise<void> {
    try {
      const response = await fetch('/api/device-info', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          battery: {
            level: deviceInfo.battery.level,
            isCharging: deviceInfo.battery.charging,
            timestamp: new Date().toISOString(),
          },
          storage: {
            totalSpace: deviceInfo.storage.quota,
            usedSpace: deviceInfo.storage.usage,
            freeSpace: deviceInfo.storage.available,
          },
          system: deviceInfo.system,
        }),
      });

      if (!response.ok) {
        console.warn('Failed to send device data to backend');
      }
    } catch (error) {
      console.warn('Error sending device data to backend:', error);
    }
  }
}

// Create global instance
export const deviceMonitor = RealTimeMonitor.getInstance();