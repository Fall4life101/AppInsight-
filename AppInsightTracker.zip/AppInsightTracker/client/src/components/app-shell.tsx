import { useState } from "react";
import Sidebar from "./sidebar";
import Topbar from "./topbar";

type AppShellProps = {
  children: React.ReactNode;
};

export default function AppShell({ children }: AppShellProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="min-h-screen flex bg-neutral-100 dark:bg-neutral-900 font-sans">
      {/* Sidebar - hidden on mobile, shown on larger screens */}
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto flex flex-col">
        <Topbar onMenuClick={toggleSidebar} />
        {children}
      </main>
    </div>
  );
}
