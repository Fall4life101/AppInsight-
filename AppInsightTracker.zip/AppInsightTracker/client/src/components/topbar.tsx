import { Search, Bell } from "lucide-react";
import { useLocation } from "wouter";

type TopbarProps = {
  onMenuClick: () => void;
};

export default function Topbar({ onMenuClick }: TopbarProps) {
  const [location] = useLocation();
  
  // Determine title based on location
  let title = "Dashboard";
  if (location === "/app-history") {
    title = "App History";
  } else if (location === "/applications") {
    title = "Applications";
  } else if (location === "/storage") {
    title = "Storage";
  } else if (location === "/battery") {
    title = "Battery";
  } else if (location === "/settings") {
    title = "Settings";
  }
  
  return (
    <header className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 h-16 flex items-center justify-between px-4 md:px-6">
      <div className="flex items-center">
        <button 
          className="md:hidden mr-2"
          onClick={onMenuClick}
          aria-label="Toggle menu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-neutral-600 dark:text-neutral-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="text-xl font-semibold text-neutral-800 dark:text-white">{title}</h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="relative">
          <input 
            type="text" 
            className="w-40 md:w-64 h-9 pl-9 pr-3 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-800 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" 
            placeholder="Search..."
          />
          <Search className="h-4 w-4 text-neutral-600 dark:text-neutral-400 absolute top-2.5 left-2.5" />
        </div>
        
        <button className="h-9 w-9 rounded-full bg-neutral-100 dark:bg-neutral-700 flex items-center justify-center">
          <Bell className="h-5 w-5 text-neutral-600 dark:text-neutral-300" />
        </button>
        
        <button className="h-9 w-9 rounded-full overflow-hidden border-2 border-neutral-100 dark:border-neutral-700">
          <svg 
            className="h-full w-full text-neutral-400 dark:text-neutral-500" 
            viewBox="0 0 24 24" 
            fill="currentColor"
          >
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
          </svg>
        </button>
      </div>
    </header>
  );
}
