import { cn, formatTime, formatBytes } from "@/lib/utils";
import { ArrowUp, ArrowDown } from "lucide-react";

type TrendProps = {
  value: number;
  direction: 'up' | 'down';
};

type StatsCardProps = {
  title: string;
  value: number;
  type: 'time' | 'number' | 'storage' | 'battery';
  icon: React.ReactNode;
  trend?: TrendProps;
  progressValue?: number;
  remainingTime?: string;
};

export default function StatsCard({ 
  title, 
  value, 
  type, 
  icon, 
  trend, 
  progressValue, 
  remainingTime 
}: StatsCardProps) {
  // Format the value based on type
  let formattedValue = '';
  
  switch (type) {
    case 'time':
      formattedValue = formatTime(value);
      break;
    case 'number':
      formattedValue = value.toString();
      break;
    case 'storage':
      formattedValue = formatBytes(value);
      break;
    case 'battery':
      formattedValue = `${value}%`;
      break;
    default:
      formattedValue = value.toString();
  }
  
  return (
    <div className="bg-white dark:bg-neutral-800 rounded-xl p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">{title}</p>
          <p className="text-2xl font-semibold text-neutral-800 dark:text-white mt-1">{formattedValue}</p>
        </div>
        <div className="h-10 w-10 rounded-lg bg-opacity-10 flex items-center justify-center" style={{ 
          backgroundColor: type === 'time' ? 'rgba(74, 144, 226, 0.1)' : 
                          type === 'number' ? 'rgba(80, 200, 120, 0.1)' : 
                          type === 'storage' ? 'rgba(255, 107, 107, 0.1)' : 
                          'rgba(34, 197, 94, 0.1)' 
        }}>
          {icon}
        </div>
      </div>
      
      {trend && (
        <div className="mt-4 flex items-center space-x-2">
          <span className={cn(
            "inline-flex items-center px-2 py-1 text-xs font-medium rounded-full",
            trend.direction === 'up' 
              ? "bg-green-100 text-green-600" 
              : "bg-red-100 text-red-600"
          )}>
            {trend.direction === 'up' ? (
              <ArrowUp className="h-3 w-3 mr-1" />
            ) : (
              <ArrowDown className="h-3 w-3 mr-1" />
            )}
            {trend.value}%
          </span>
          <span className="text-xs text-neutral-600 dark:text-neutral-400">vs last week</span>
        </div>
      )}
      
      {type === 'storage' && progressValue !== undefined && (
        <div className="mt-4">
          <div className="relative w-full h-2 bg-neutral-100 dark:bg-neutral-700 rounded-full">
            <div 
              className="absolute top-0 left-0 h-2 bg-red-500 rounded-full" 
              style={{ width: `${progressValue}%` }}
            ></div>
          </div>
          <div className="mt-1 flex justify-between text-xs text-neutral-600 dark:text-neutral-400">
            <span>{Math.round(progressValue)}% used</span>
            <span>{100 - Math.round(progressValue)}% free</span>
          </div>
        </div>
      )}
      
      {type === 'battery' && (
        <div className="mt-4">
          <div className="relative w-full h-5 border-2 border-neutral-300 dark:border-neutral-600 rounded-md flex items-center">
            <div className="absolute right-0 top-0 bottom-0 w-2 bg-neutral-300 dark:bg-neutral-600 rounded-r-sm"></div>
            <div className="h-full bg-green-500 rounded-l-sm ml-0.5 transition-all duration-1000" style={{ width: `${value}%` }}></div>
          </div>
          {remainingTime && (
            <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-2">Estimated {remainingTime} remaining</p>
          )}
        </div>
      )}
    </div>
  );
}
