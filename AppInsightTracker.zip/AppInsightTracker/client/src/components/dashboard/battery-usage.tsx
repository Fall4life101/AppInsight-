import { Card, CardContent } from "@/components/ui/card";
import { batteryData } from "@/lib/mock-data";

export default function BatteryUsage() {
  return (
    <Card className="h-80">
      <CardContent className="p-5">
        <h3 className="font-semibold text-neutral-800 mb-5">Battery Usage</h3>
        
        <div className="flex flex-col items-center justify-center h-48 mb-4">
          <div className="relative h-44 w-44 flex items-center justify-center">
            <svg viewBox="0 0 100 100" width="176" height="176">
              {/* Background circle */}
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke="#E4E8F0" 
                strokeWidth="10" 
                strokeLinecap="round" 
              />
              
              {/* Progress circle */}
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke="#22C55E" 
                strokeWidth="10" 
                strokeLinecap="round" 
                strokeDasharray="283" 
                strokeDashoffset={283 * (1 - batteryData.level / 100)} 
                transform="rotate(-90 50 50)" 
              />
              
              {/* Text in the middle */}
              <text 
                x="50" 
                y="45" 
                textAnchor="middle" 
                dominantBaseline="middle" 
                fontSize="24" 
                fontWeight="bold" 
                fill="#334155"
              >
                {batteryData.level}%
              </text>
              <text 
                x="50" 
                y="65" 
                textAnchor="middle" 
                dominantBaseline="middle" 
                fontSize="12" 
                fill="#64748B"
              >
                Remaining
              </text>
            </svg>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-neutral-600">Status</span>
            <span className="text-neutral-800 font-medium">{batteryData.status}</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-neutral-600">Remaining Time</span>
            <span className="text-neutral-800 font-medium">{batteryData.remainingTime}</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-neutral-600">Temperature</span>
            <span className="text-neutral-800 font-medium">{batteryData.temperature}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
