import { Card, CardContent } from "@/components/ui/card";
import { formatBytes } from "@/lib/utils";
import { storageData, totalStorage } from "@/lib/mock-data";

export default function StorageBreakdown() {
  return (
    <Card className="h-80">
      <CardContent className="p-5">
        <h3 className="font-semibold text-neutral-800 mb-5">Storage Breakdown</h3>
        
        <div className="flex items-center justify-center h-48">
          <div className="relative h-40 w-40">
            <svg width="160" height="160" viewBox="0 0 160 160">
              {/* Background circle */}
              <circle cx="80" cy="80" r="70" fill="transparent" stroke="#E4E8F0" strokeWidth="20" />
              
              {/* Data segments */}
              <circle 
                cx="80" 
                cy="80" 
                r="70" 
                fill="transparent" 
                stroke={storageData[0].color}
                strokeWidth="20" 
                strokeDasharray="439.6" 
                strokeDashoffset={439.6 * (1 - storageData[0].percentage / 100)} 
                transform="rotate(-90 80 80)" 
              />
              
              <circle 
                cx="80" 
                cy="80" 
                r="70" 
                fill="transparent" 
                stroke={storageData[1].color}
                strokeWidth="20" 
                strokeDasharray="439.6" 
                strokeDashoffset={439.6 * (1 - storageData[1].percentage / 100)} 
                transform="rotate(40 80 80)" 
              />
              
              <circle 
                cx="80" 
                cy="80" 
                r="70" 
                fill="transparent" 
                stroke={storageData[2].color}
                strokeWidth="20" 
                strokeDasharray="439.6" 
                strokeDashoffset={439.6 * (1 - storageData[2].percentage / 100)} 
                transform="rotate(0 80 80)" 
              />
              
              <circle 
                cx="80" 
                cy="80" 
                r="70" 
                fill="transparent" 
                stroke={storageData[3].color}
                strokeWidth="20" 
                strokeDasharray="439.6" 
                strokeDashoffset={439.6 * (1 - storageData[3].percentage / 100)} 
                transform="rotate(-45 80 80)" 
              />
              
              {/* Center white circle and text */}
              <circle cx="80" cy="80" r="50" fill="white" />
              <text x="80" y="75" textAnchor="middle" dominantBaseline="middle" fontSize="24" fontWeight="bold" fill="#334155">
                {formatBytes(totalStorage.used).split(' ')[0]}
              </text>
              <text x="80" y="95" textAnchor="middle" dominantBaseline="middle" fontSize="14" fill="#64748B">
                GB Used
              </text>
            </svg>
          </div>
        </div>
        
        <div className="space-y-3 mt-2">
          {storageData.map(item => (
            <div key={item.id} className="flex items-center justify-between">
              <div className="flex items-center">
                <div 
                  className="h-3 w-3 rounded-full mr-2" 
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-sm text-neutral-600">{item.name}</span>
              </div>
              <span className="text-sm font-medium text-neutral-800">{formatBytes(item.size)}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
