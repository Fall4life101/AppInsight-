import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { appUsageTimeline } from "@/lib/mock-data";

type TimeFrame = 'daily' | 'weekly' | 'monthly';

export default function AppUsageChart() {
  const [timeframe, setTimeframe] = useState<TimeFrame>('daily');
  
  return (
    <Card className="col-span-1 lg:col-span-2 h-96">
      <CardContent className="p-5">
        <div className="flex justify-between items-center mb-5">
          <h3 className="font-semibold text-neutral-800">App Usage Timeline</h3>
          <div className="flex space-x-2">
            <Button 
              variant={timeframe === 'daily' ? 'default' : 'ghost'} 
              size="sm"
              onClick={() => setTimeframe('daily')}
              className="text-xs"
            >
              Daily
            </Button>
            <Button 
              variant={timeframe === 'weekly' ? 'default' : 'ghost'} 
              size="sm"
              onClick={() => setTimeframe('weekly')}
              className="text-xs"
            >
              Weekly
            </Button>
            <Button 
              variant={timeframe === 'monthly' ? 'default' : 'ghost'} 
              size="sm"
              onClick={() => setTimeframe('monthly')}
              className="text-xs"
            >
              Monthly
            </Button>
          </div>
        </div>
        
        <div className="h-[calc(100%-2.5rem)] flex flex-col">
          {/* Chart Legend */}
          <div className="flex items-center space-x-4 mb-4 flex-wrap">
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-primary mr-2"></div>
              <span className="text-xs text-neutral-600">Social Media</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-xs text-neutral-600">Productivity</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-red-500 mr-2"></div>
              <span className="text-xs text-neutral-600">Entertainment</span>
            </div>
            <div className="flex items-center">
              <div className="h-3 w-3 rounded-full bg-neutral-400 mr-2"></div>
              <span className="text-xs text-neutral-600">Other</span>
            </div>
          </div>
          
          {/* Chart Visualization */}
          <div className="flex-1 flex items-end relative">
            {/* Chart Y-Axis Labels */}
            <div className="absolute left-0 top-0 bottom-10 flex flex-col justify-between text-xs text-neutral-600 pointer-events-none">
              <span>4h</span>
              <span>3h</span>
              <span>2h</span>
              <span>1h</span>
              <span>0</span>
            </div>
            
            {/* Chart Bars */}
            <div className="flex-1 flex items-end mx-6">
              {appUsageTimeline.map((data, index) => (
                <div key={index} className="flex flex-col items-center flex-1">
                  <div className="w-full flex justify-center space-x-1 mb-1">
                    <div 
                      className="w-1 bg-primary rounded-t-sm transition-all duration-500" 
                      style={{ height: `${data.socialMedia}%` }}
                    ></div>
                    <div 
                      className="w-1 bg-green-500 rounded-t-sm transition-all duration-500" 
                      style={{ height: `${data.productivity}%` }}
                    ></div>
                    <div 
                      className="w-1 bg-red-500 rounded-t-sm transition-all duration-500" 
                      style={{ height: `${data.entertainment}%` }}
                    ></div>
                    <div 
                      className="w-1 bg-neutral-400 rounded-t-sm transition-all duration-500" 
                      style={{ height: `${data.other}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-neutral-600 mt-1">{data.hour}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
