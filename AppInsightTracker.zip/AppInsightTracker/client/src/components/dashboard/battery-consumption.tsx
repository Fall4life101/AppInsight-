import { Card, CardContent } from "@/components/ui/card";
import { batteryConsumptionData } from "@/lib/mock-data";
import { 
  Facebook, 
  Instagram, 
  Youtube, 
  Calendar,
} from "lucide-react";

// Map of app icon names to components
const iconMap: Record<string, React.ReactNode> = {
  facebook: <Facebook className="h-4 w-4 text-white" />,
  instagram: <Instagram className="h-4 w-4 text-white" />,
  youtube: <Youtube className="h-4 w-4 text-white" />,
  calendar: <Calendar className="h-4 w-4 text-white" />,
  whatsapp: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.8 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.23-8.24 8.23-1.48 0-2.93-.39-4.19-1.15l-.3-.17-3.12.82.83-3.04-.2-.32a8.188 8.188 0 0 1-1.26-4.38c.01-4.54 3.7-8.24 8.25-8.24M8.53 7.33c-.16 0-.43.06-.66.31-.22.25-.87.86-.87 2.07 0 1.22.89 2.39 1 2.56.14.17 1.76 2.67 4.25 3.73.59.27 1.05.42 1.41.53.59.19 1.13.16 1.56.1.48-.07 1.46-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.16-.48-.27-.25-.14-1.47-.74-1.69-.82-.23-.08-.37-.12-.56.12-.16.25-.64.81-.78.97-.15.17-.29.19-.53.07-.26-.13-1.06-.39-2-1.23-.74-.66-1.23-1.47-1.38-1.72-.12-.24-.01-.39.11-.5.11-.11.27-.29.37-.44.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.11-.56-1.35-.77-1.84-.2-.48-.4-.42-.56-.43-.14 0-.3-.01-.47-.01z"/>
    </svg>
  ),
  discord: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.27 5.33C17.94 4.71 16.5 4.26 15 4a.09.09 0 0 0-.07.03c-.18.33-.39.76-.53 1.09a16.09 16.09 0 0 0-4.8 0c-.14-.34-.35-.76-.54-1.09c-.01-.02-.04-.03-.07-.03c-1.5.26-2.93.71-4.27 1.33c-.01 0-.02.01-.03.02c-2.72 4.07-3.47 8.03-3.1 11.95c0 .02.01.04.03.05c1.8 1.32 3.53 2.12 5.24 2.65c.03.01.06 0 .07-.02c.4-.55.76-1.13 1.07-1.74c.02-.04 0-.08-.04-.09c-.57-.22-1.11-.48-1.64-.78c-.04-.02-.04-.08-.01-.11c.11-.08.22-.17.33-.25c.02-.02.05-.02.07-.01c3.44 1.57 7.15 1.57 10.55 0c.02-.01.05-.01.07.01c.11.09.22.17.33.26c.04.03.04.09-.01.11c-.52.31-1.07.56-1.64.78c-.04.01-.05.06-.04.09c.32.61.68 1.19 1.07 1.74c.03.01.06.02.09.01c1.72-.53 3.45-1.33 5.25-2.65c.02-.01.03-.03.03-.05c.44-4.53-.73-8.46-3.1-11.95c-.01-.01-.02-.02-.04-.02zM8.52 14.91c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12c0 1.17-.84 2.12-1.89 2.12zm6.97 0c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12c0 1.17-.83 2.12-1.89 2.12z"/>
    </svg>
  )
};

function getBatteryBarColor(percentage: number): string {
  if (percentage >= 15) {
    return "bg-red-500";
  } else if (percentage >= 8) {
    return "bg-amber-500";
  }
  return "bg-green-500";
}

export default function BatteryConsumption() {
  return (
    <Card className="h-80">
      <CardContent className="p-5">
        <h3 className="font-semibold text-neutral-800 mb-5">Battery Consumption by App</h3>
        
        <div className="space-y-4 h-[calc(100%-2.5rem)] overflow-y-auto">
          {batteryConsumptionData.map(app => (
            <div key={app.id} className="flex items-center">
              <div 
                className="h-8 w-8 rounded-lg mr-3 overflow-hidden flex-shrink-0 flex items-center justify-center" 
                style={{ backgroundColor: app.color }}
              >
                {iconMap[app.icon]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-medium text-neutral-800 text-sm">{app.name}</h4>
                  <span className="text-xs font-medium text-neutral-600">{app.percentage}%</span>
                </div>
                <div className="w-full h-1.5 bg-neutral-100 rounded-full">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${getBatteryBarColor(app.percentage)}`}
                    style={{ width: `${app.percentage}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
