import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { nativeDeviceService, type NativeDeviceInfo } from "@/lib/native-device-service";
import { formatBytes, formatTimeAgo, formatDuration } from "@/lib/device-info";
import { 
  Smartphone, 
  Battery, 
  HardDrive, 
  Clock, 
  Download, 
  Zap, 
  Cpu,
  Info,
  CheckCircle,
  XCircle,
  AlertCircle,
  BarChart3,
  Package,
  Settings
} from "lucide-react";

export default function NativeFeaturesDashboard() {
  const [nativeData, setNativeData] = useState<NativeDeviceInfo>({});
  const [isNative, setIsNative] = useState(false);
  const [hasPermissions, setHasPermissions] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadNativeData = async () => {
      setIsLoading(true);
      setIsNative(nativeDeviceService.isRunningNatively());
      
      if (nativeDeviceService.isRunningNatively()) {
        const permissionsGranted = await nativeDeviceService.requestPermissions();
        setHasPermissions(permissionsGranted);
      }

      // Load all native data
      const [
        appUsage,
        systemStorage,
        appBatteryUsage,
        installedApps,
        batteryInfo,
        systemInfo
      ] = await Promise.all([
        nativeDeviceService.getDetailedAppUsage(),
        nativeDeviceService.getSystemStorageBreakdown(),
        nativeDeviceService.getAppBatteryUsage(),
        nativeDeviceService.getInstalledApps(),
        nativeDeviceService.getEnhancedBatteryInfo(),
        nativeDeviceService.getSystemInfo()
      ]);

      setNativeData({
        appUsage,
        systemStorage,
        appBatteryUsage,
        installedApps,
        batteryInfo,
        systemInfo
      });
      
      setIsLoading(false);
    };

    loadNativeData();
  }, []);

  const getStatusBadge = (isAvailable: boolean, isNativeOnly: boolean = false) => {
    if (isAvailable) {
      return <Badge variant="default" className="bg-green-500">Available</Badge>;
    } else if (isNativeOnly && !isNative) {
      return <Badge variant="secondary">Native Only</Badge>;
    } else {
      return <Badge variant="destructive">Unavailable</Badge>;
    }
  };

  const getStatusIcon = (isAvailable: boolean) => {
    if (isAvailable) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    } else {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading native device features...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Platform Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Platform Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Running as Native App:</span>
              <div className="flex items-center gap-2">
                {getStatusIcon(isNative)}
                <span className="font-medium">{isNative ? 'Yes' : 'No'}</span>
              </div>
            </div>
            
            {isNative && (
              <div className="flex items-center justify-between">
                <span>Usage Statistics Permission:</span>
                <div className="flex items-center gap-2">
                  {getStatusIcon(hasPermissions)}
                  <span className="font-medium">{hasPermissions ? 'Granted' : 'Required'}</span>
                </div>
              </div>
            )}
            
            {!isNative && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  <span className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Web Version Limitations
                  </span>
                </div>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  You're running the web version. To access detailed app usage, system storage, and battery statistics, 
                  you need to install the native mobile app.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Feature Availability Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Availability</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Detailed App Usage</span>
                {getStatusBadge(isNative && hasPermissions, true)}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">System Storage Breakdown</span>
                {getStatusBadge(isNative, true)}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">App Battery Consumption</span>
                {getStatusBadge(isNative && hasPermissions, true)}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Installed Apps List</span>
                {getStatusBadge(isNative, true)}
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Enhanced Battery Info</span>
                {getStatusBadge(isNative, true)}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">System Information</span>
                {getStatusBadge(isNative, true)}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Real-time Monitoring</span>
                {getStatusBadge(true)}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Basic Device Info</span>
                {getStatusBadge(true)}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Native Features Data */}
      <Tabs defaultValue="app-usage" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="app-usage">App Usage</TabsTrigger>
          <TabsTrigger value="storage">Storage</TabsTrigger>
          <TabsTrigger value="battery">Battery</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        <TabsContent value="app-usage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Detailed App Usage Statistics
                {getStatusBadge(isNative && hasPermissions, true)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {nativeData.appUsage && nativeData.appUsage.length > 0 ? (
                <div className="space-y-4">
                  {nativeData.appUsage.map((app, index) => (
                    <div key={app.appId} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Package className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-medium">{app.appName}</h4>
                          <p className="text-sm text-muted-foreground">
                            {app.category} • Last used {formatTimeAgo(app.lastUsed)}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{formatDuration(app.usageTime * 60)}</div>
                        {app.batteryUsage && (
                          <div className="text-sm text-muted-foreground">
                            {app.batteryUsage}% battery
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>
                    {isNative 
                      ? "No app usage data available. Permission may be required." 
                      : "Install the native app to see detailed usage statistics."}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="storage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5" />
                System Storage Breakdown
                {getStatusBadge(isNative, true)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {nativeData.systemStorage ? (
                <div className="space-y-4">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold">
                      {formatBytes(nativeData.systemStorage.usedStorage)} / {formatBytes(nativeData.systemStorage.totalStorage)}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Storage Used</div>
                  </div>
                  
                  <Progress 
                    value={(nativeData.systemStorage.usedStorage / nativeData.systemStorage.totalStorage) * 100} 
                    className="h-3"
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Apps:</span>
                        <span className="font-medium">{formatBytes(nativeData.systemStorage.appStorage)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>System:</span>
                        <span className="font-medium">{formatBytes(nativeData.systemStorage.systemStorage)}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Media:</span>
                        <span className="font-medium">{formatBytes(nativeData.systemStorage.mediaStorage)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Other:</span>
                        <span className="font-medium">{formatBytes(nativeData.systemStorage.otherStorage)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <HardDrive className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>Install the native app to see detailed storage breakdown.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="battery" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Battery className="h-5 w-5" />
                  Enhanced Battery Info
                  {getStatusBadge(isNative, true)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {nativeData.batteryInfo ? (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Level:</span>
                      <span className="font-medium">{nativeData.batteryInfo.level}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Health:</span>
                      <span className="font-medium">{nativeData.batteryInfo.health}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Temperature:</span>
                      <span className="font-medium">{nativeData.batteryInfo.temperature}°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Voltage:</span>
                      <span className="font-medium">{nativeData.batteryInfo.voltage}V</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Technology:</span>
                      <span className="font-medium">{nativeData.batteryInfo.technology}</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Battery className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>Install the native app for detailed battery information.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  App Battery Usage
                  {getStatusBadge(isNative && hasPermissions, true)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {nativeData.appBatteryUsage && nativeData.appBatteryUsage.length > 0 ? (
                  <div className="space-y-3">
                    {nativeData.appBatteryUsage.map((app, index) => (
                      <div key={app.appId} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{app.appName}</div>
                          <div className="text-xs text-muted-foreground">
                            {formatDuration(app.foregroundTime * 60)} fg • {formatDuration(app.backgroundTime * 60)} bg
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">{app.batteryPercentage}%</div>
                          <Progress value={app.batteryPercentage} className="w-16 h-2" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Zap className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>
                      {isNative 
                        ? "No battery usage data available." 
                        : "Install the native app to see app-specific battery usage."}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  System Information
                  {getStatusBadge(isNative, true)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {nativeData.systemInfo ? (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Device:</span>
                      <span className="font-medium">{nativeData.systemInfo.deviceModel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Manufacturer:</span>
                      <span className="font-medium">{nativeData.systemInfo.manufacturer}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>OS:</span>
                      <span className="font-medium">{nativeData.systemInfo.operatingSystem} {nativeData.systemInfo.osVersion}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>CPU:</span>
                      <span className="font-medium">{nativeData.systemInfo.cpuInfo}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Architecture:</span>
                      <span className="font-medium">{nativeData.systemInfo.architecture}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Memory:</span>
                      <span className="font-medium">
                        {formatBytes(nativeData.systemInfo.availableMemory)} / {formatBytes(nativeData.systemInfo.totalMemory)}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Cpu className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>Install the native app for detailed system information.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Installed Apps
                  {getStatusBadge(isNative, true)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {nativeData.installedApps && nativeData.installedApps.length > 0 ? (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {nativeData.installedApps.map((app, index) => (
                      <div key={app.appId} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-primary/10 rounded flex items-center justify-center">
                            <Package className="h-3 w-3 text-primary" />
                          </div>
                          <div>
                            <div className="font-medium">{app.appName}</div>
                            <div className="text-xs text-muted-foreground">{app.category}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">{formatBytes(app.size)}</div>
                          <div className="text-xs text-muted-foreground">v{app.version}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Package className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>Install the native app to see installed apps list.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}