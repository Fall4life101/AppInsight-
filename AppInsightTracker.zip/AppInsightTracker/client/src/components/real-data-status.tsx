import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

interface RealDataCapabilities {
  battery: boolean;
  storage: boolean;
  network: boolean;
  screen: boolean;
  system: boolean;
}

export default function RealDataStatus() {
  const [capabilities, setCapabilities] = useState<RealDataCapabilities>({
    battery: false,
    storage: false,
    network: false,
    screen: true,
    system: true,
  });

  useEffect(() => {
    const checkCapabilities = async () => {
      const newCapabilities = { ...capabilities };

      // Check Battery API
      if ('getBattery' in navigator) {
        try {
          await (navigator as any).getBattery();
          newCapabilities.battery = true;
        } catch (e) {
          newCapabilities.battery = false;
        }
      }

      // Check Storage API
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        try {
          await navigator.storage.estimate();
          newCapabilities.storage = true;
        } catch (e) {
          newCapabilities.storage = false;
        }
      }

      // Check Network Information API
      const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
      newCapabilities.network = !!connection;

      setCapabilities(newCapabilities);
    };

    checkCapabilities();
  }, []);

  const getStatusIcon = (supported: boolean) => {
    return supported ? (
      <CheckCircle className="h-4 w-4 text-green-500" />
    ) : (
      <XCircle className="h-4 w-4 text-red-500" />
    );
  };

  const getStatusBadge = (supported: boolean) => {
    return supported ? (
      <Badge variant="secondary" className="text-green-700 bg-green-100 dark:bg-green-900 dark:text-green-300">
        Real Data
      </Badge>
    ) : (
      <Badge variant="secondary" className="text-yellow-700 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300">
        Simulated
      </Badge>
    );
  };

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <AlertCircle className="h-5 w-5 text-blue-500" />
          <h3 className="text-lg font-semibold">Real Data Capabilities</h3>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4">
          Web browsers can only access limited device information due to privacy and security restrictions. 
          Here's what data is actually available vs simulated:
        </p>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(capabilities.battery)}
              <span className="text-sm">Battery Level & Charging Status</span>
            </div>
            {getStatusBadge(capabilities.battery)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(capabilities.storage)}
              <span className="text-sm">Browser Storage Usage</span>
            </div>
            {getStatusBadge(capabilities.storage)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(capabilities.network)}
              <span className="text-sm">Network Connection Type</span>
            </div>
            {getStatusBadge(capabilities.network)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(capabilities.screen)}
              <span className="text-sm">Screen Resolution & Orientation</span>
            </div>
            {getStatusBadge(capabilities.screen)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(capabilities.system)}
              <span className="text-sm">Browser & System Info</span>
            </div>
            {getStatusBadge(capabilities.system)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(false)}
              <span className="text-sm">App Usage Statistics</span>
            </div>
            {getStatusBadge(false)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(false)}
              <span className="text-sm">System Storage Breakdown</span>
            </div>
            {getStatusBadge(false)}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon(false)}
              <span className="text-sm">Per-App Battery Usage</span>
            </div>
            {getStatusBadge(false)}
          </div>
        </div>

        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            <strong>Note:</strong> To access full device statistics like app usage and system storage, 
            you would need to convert this to a native mobile app using Capacitor. 
            The web version shows real browser data where available and simulates the rest for demonstration.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}