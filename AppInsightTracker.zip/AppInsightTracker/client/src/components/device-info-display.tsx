import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { deviceMonitor } from "@/lib/real-time-monitor";
import { formatBytes, formatTimeRemaining } from "@/lib/device-info";
import type { DeviceInfo } from "@/lib/device-info";
import { Battery, HardDrive, Wifi, Monitor, Cpu, RefreshCw } from "lucide-react";

export default function DeviceInfoDisplay() {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  useEffect(() => {
    const handleDeviceUpdate = (data: DeviceInfo) => {
      setDeviceInfo(data);
      setLastUpdated(new Date());
    };

    deviceMonitor.addListener(handleDeviceUpdate);
    
    // Get initial data if available
    const initialData = deviceMonitor.getLastData();
    if (initialData) {
      setDeviceInfo(initialData);
      setLastUpdated(new Date());
    }

    return () => {
      deviceMonitor.removeListener(handleDeviceUpdate);
    };
  }, []);

  if (!deviceInfo) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5 animate-spin" />
            Loading Real Device Information...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Live Device Information</h3>
        {lastUpdated && (
          <p className="text-sm text-muted-foreground">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Battery Information */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Battery className="h-4 w-4" />
              Battery Status
              <Badge variant={deviceInfo.battery.supported ? "default" : "secondary"}>
                {deviceInfo.battery.supported ? "Real Data" : "Not Available"}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {deviceInfo.battery.supported ? (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Level:</span>
                  <span className="font-medium">{deviceInfo.battery.level}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className="font-medium">
                    {deviceInfo.battery.charging ? "Charging" : "Discharging"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Charging Time:</span>
                  <span className="font-medium">
                    {formatTimeRemaining(deviceInfo.battery.chargingTime)}
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Battery API not supported in this browser
              </p>
            )}
          </CardContent>
        </Card>

        {/* Storage Information */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <HardDrive className="h-4 w-4" />
              Browser Storage
              <Badge variant={deviceInfo.storage.supported ? "default" : "secondary"}>
                {deviceInfo.storage.supported ? "Real Data" : "Not Available"}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {deviceInfo.storage.supported ? (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Total Quota:</span>
                  <span className="font-medium">{formatBytes(deviceInfo.storage.quota)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Used:</span>
                  <span className="font-medium">{formatBytes(deviceInfo.storage.usage)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Available:</span>
                  <span className="font-medium">{formatBytes(deviceInfo.storage.available)}</span>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Storage API not supported in this browser
              </p>
            )}
          </CardContent>
        </Card>

        {/* Network Information */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Wifi className="h-4 w-4" />
              Network Connection
              <Badge variant={deviceInfo.network.supported ? "default" : "secondary"}>
                {deviceInfo.network.supported ? "Real Data" : "Not Available"}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {deviceInfo.network.supported ? (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Type:</span>
                  <span className="font-medium">{deviceInfo.network.effectiveType}</span>
                </div>
                <div className="flex justify-between">
                  <span>Downlink:</span>
                  <span className="font-medium">{deviceInfo.network.downlink} Mbps</span>
                </div>
                <div className="flex justify-between">
                  <span>RTT:</span>
                  <span className="font-medium">{deviceInfo.network.rtt}ms</span>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Network Information API not supported
              </p>
            )}
          </CardContent>
        </Card>

        {/* Screen Information */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Monitor className="h-4 w-4" />
              Screen Information
              <Badge variant="default">Real Data</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Resolution:</span>
                <span className="font-medium">{deviceInfo.screen.width} × {deviceInfo.screen.height}</span>
              </div>
              <div className="flex justify-between">
                <span>Color Depth:</span>
                <span className="font-medium">{deviceInfo.screen.colorDepth} bits</span>
              </div>
              <div className="flex justify-between">
                <span>Orientation:</span>
                <span className="font-medium">{deviceInfo.screen.orientation}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Information */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Cpu className="h-4 w-4" />
            System Information
            <Badge variant="default">Real Data</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Platform:</span>
                <span className="font-medium">{deviceInfo.system.platform}</span>
              </div>
              <div className="flex justify-between">
                <span>Language:</span>
                <span className="font-medium">{deviceInfo.system.language}</span>
              </div>
              <div className="flex justify-between">
                <span>Online:</span>
                <span className="font-medium">{deviceInfo.system.onLine ? "Yes" : "No"}</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Cookies:</span>
                <span className="font-medium">{deviceInfo.system.cookieEnabled ? "Enabled" : "Disabled"}</span>
              </div>
              {deviceInfo.system.memoryInfo && (
                <>
                  <div className="flex justify-between">
                    <span>JS Heap Used:</span>
                    <span className="font-medium">{formatBytes(deviceInfo.system.memoryInfo.usedJSHeapSize)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>JS Heap Limit:</span>
                    <span className="font-medium">{formatBytes(deviceInfo.system.memoryInfo.jsHeapSizeLimit)}</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}