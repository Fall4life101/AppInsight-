import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Smartphone, HardDrive, Battery, Settings, History, Sun, Moon } from "lucide-react";
import { useTheme } from "@/components/ui/theme-provider";
import { Button } from "@/components/ui/button";

type SidebarProps = {
  open: boolean;
  onClose: () => void;
};

type NavLinkProps = {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
};

function NavLink({ href, icon, children, active }: NavLinkProps) {
  return (
    <Link href={href}>
      <div
        className={cn(
          "flex items-center py-2 px-4 font-medium cursor-pointer",
          active
            ? "text-primary"
            : "text-neutral-600 dark:text-neutral-300 hover:text-primary dark:hover:text-primary"
        )}
      >
        {icon}
        <span className="hidden md:inline ml-3">{children}</span>
      </div>
    </Link>
  );
}

export default function Sidebar({ open, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "w-20 md:w-64 bg-white dark:bg-neutral-900 border-r border-neutral-200 dark:border-neutral-800 flex-shrink-0 flex flex-col",
          "fixed inset-y-0 left-0 z-50 md:static md:z-auto",
          "transform transition-transform duration-200 ease-in-out",
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        <div className="h-16 flex items-center justify-center md:justify-start px-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
          </div>
          <span className="ml-3 text-lg font-semibold text-neutral-800 dark:text-white hidden md:inline">AppInsight</span>
        </div>
        
        <nav className="py-4 flex-1">
          <ul className="space-y-1">
            <li>
              <NavLink 
                href="/" 
                icon={<Home className="h-5 w-5 mr-3" />}
                active={location === "/"}
              >
                Dashboard
              </NavLink>
            </li>
            <li>
              <NavLink 
                href="/applications" 
                icon={<Smartphone className="h-5 w-5 mr-3" />}
                active={location === "/applications"}
              >
                Applications
              </NavLink>
            </li>
            <li>
              <NavLink 
                href="/app-history" 
                icon={<History className="h-5 w-5 mr-3" />}
                active={location === "/app-history"}
              >
                App History
              </NavLink>
            </li>
            <li>
              <NavLink 
                href="/storage" 
                icon={<HardDrive className="h-5 w-5 mr-3" />}
                active={location === "/storage"}
              >
                Storage
              </NavLink>
            </li>
            <li>
              <NavLink 
                href="/battery" 
                icon={<Battery className="h-5 w-5 mr-3" />}
                active={location === "/battery"}
              >
                Battery
              </NavLink>
            </li>
            <li>
              <NavLink 
                href="/settings" 
                icon={<Settings className="h-5 w-5 mr-3" />}
                active={location === "/settings"}
              >
                Settings
              </NavLink>
            </li>
          </ul>
        </nav>

        <div className="p-4 border-t border-neutral-200 dark:border-neutral-800">
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full justify-between"
            onClick={toggleTheme}
          >
            <span className="flex items-center">
              {theme === 'dark' ? (
                <Sun className="h-4 w-4 mr-2" />
              ) : (
                <Moon className="h-4 w-4 mr-2" />
              )}
              <span className="hidden md:inline">
                {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
              </span>
            </span>
          </Button>
        </div>
      </aside>
    </>
  );
}
