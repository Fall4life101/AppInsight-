import React, { useEffect, useState } from "react";
import AppShell from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatTime, getFormattedDate } from "@/lib/utils";
import { useAppHistory } from "@/hooks/use-device-data";
import { Download, Trash2, Calendar, Clock, RefreshCw } from "lucide-react";

// Mock data for app history
type AppHistoryItem = {
  id: string;
  name: string;
  icon: string;
  color: string;
  date: string;
  time: string;
  size: string;
  status: "installed" | "deleted";
};

const mockAppHistory: AppHistoryItem[] = [
  {
    id: "1",
    name: "Facebook",
    icon: "facebook",
    color: "#4267B2",
    date: "2023-04-10",
    time: "14:32",
    size: "56.7 MB",
    status: "installed"
  },
  {
    id: "2",
    name: "Instagram",
    icon: "instagram",
    color: "#E1306C",
    date: "2023-04-09",
    time: "09:15",
    size: "42.3 MB",
    status: "installed"
  },
  {
    id: "3",
    name: "Twitter",
    icon: "twitter",
    color: "#1DA1F2",
    date: "2023-04-08",
    time: "18:45",
    size: "30.1 MB",
    status: "deleted"
  },
  {
    id: "4",
    name: "WhatsApp",
    icon: "whatsapp",
    color: "#25D366",
    date: "2023-04-07",
    time: "11:20",
    size: "48.5 MB",
    status: "installed"
  },
  {
    id: "5",
    name: "Spotify",
    icon: "music",
    color: "#1DB954",
    date: "2023-04-06",
    time: "16:05",
    size: "62.8 MB",
    status: "deleted"
  },
  {
    id: "6",
    name: "Gmail",
    icon: "mail",
    color: "#D44638",
    date: "2023-04-05",
    time: "10:38",
    size: "24.9 MB",
    status: "installed"
  },
  {
    id: "7",
    name: "Slack",
    icon: "message-square",
    color: "#4A154B",
    date: "2023-04-04",
    time: "15:12",
    size: "51.2 MB",
    status: "deleted"
  }
];

// Icon component mapper
const getIconComponent = (iconName: string) => {
  // Just using a simple approach for the demo
  switch (iconName) {
    case "facebook":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm3.126 8.283h-1.756c-.258 0-.546.03-.546.546v1.258h2.302l-.241 2.302h-2.06V19H9.123v-6.609H7.5v-2.302h1.623V8.557C9.123 6.558 9.91 5 12.153 5h2.973v3.283z" />
      </svg>;
    case "instagram":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <path d="M16.5 0h-9C3.4 0 0 3.4 0 7.5v9C0 20.6 3.4 24 7.5 24h9c4.1 0 7.5-3.4 7.5-7.5v-9C24 3.4 20.6 0 16.5 0zm5 16.5c0 2.8-2.2 5-5 5h-9c-2.8 0-5-2.2-5-5v-9c0-2.8 2.2-5 5-5h9c2.8 0 5 2.2 5 5v9z" />
        <path d="M12 7.5C9.5 7.5 7.5 9.5 7.5 12s2 4.5 4.5 4.5 4.5-2 4.5-4.5-2-4.5-4.5-4.5zm0 7c-1.4 0-2.5-1.1-2.5-2.5S10.6 9.5 12 9.5s2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5zM17 6c-.6 0-1 .4-1 1s.4 1 1 1 1-.4 1-1-.4-1-1-1z" />
      </svg>;
    case "twitter":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.954 4.569a10.158 10.158 0 01-2.82.77 4.92 4.92 0 002.165-2.723 9.83 9.83 0 01-3.127 1.195 4.897 4.897 0 00-8.384 4.482A13.897 13.897 0 011.642 3.09a4.917 4.917 0 001.52 6.573 4.82 4.82 0 01-2.224-.618v.063a4.897 4.897 0 003.947 4.803 4.9 4.9 0 01-2.214.085 4.903 4.903 0 004.583 3.401 9.826 9.826 0 01-6.087 2.105c-.394 0-.783-.022-1.166-.067a13.849 13.849 0 007.499 2.205c8.999 0 13.908-7.452 13.908-13.908 0-.212-.004-.423-.013-.633a9.93 9.93 0 002.46-2.532l-.047-.02z" />
      </svg>;
    case "whatsapp":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.8 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 012.41 5.83c0 4.54-3.7 8.23-8.24 8.23-1.48 0-2.93-.39-4.19-1.15l-.3-.17-3.12.82.83-3.04-.2-.32a8.188 8.188 0 01-1.26-4.38c.01-4.54 3.7-8.24 8.25-8.24M8.53 7.33c-.16 0-.43.06-.66.31-.22.25-.87.86-.87 2.07 0 1.22.89 2.39 1 2.56.14.17 1.76 2.67 4.25 3.73.59.27 1.05.42 1.41.53.59.19 1.13.16 1.56.1.48-.07 1.46-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.16-.48-.27-.25-.14-1.47-.74-1.69-.82-.23-.08-.37-.12-.56.12-.16.25-.64.81-.78.97-.15.17-.29.19-.53.07-.26-.13-1.06-.39-2-1.23-.74-.66-1.23-1.47-1.38-1.72-.12-.24-.01-.39.11-.5.11-.11.27-.29.37-.44.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.11-.56-1.35-.77-1.84-.2-.48-.4-.42-.56-.43-.14 0-.3-.01-.47-.01z" />
      </svg>;
    case "music":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <circle cx="5.5" cy="17.5" r="2.5" />
        <circle cx="17.5" cy="15.5" r="2.5" />
        <path d="M22 3l-1.67 1.67L18.67 3L17 4.67L15.33 3l-1.66 1.67L12 3l-1.67 1.67L8.67 3L7 4.67L5.33 3L3.67 4.67L2 3v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V3zM5.5 20c-1.38 0-2.5-1.12-2.5-2.5S4.12 15 5.5 15s2.5 1.12 2.5 2.5S6.88 20 5.5 20zm9 0c0-.69.33-1.32.88-1.73c-.3-.58-.47-1.23-.47-1.92c0-2.33 1.9-4.23 4.23-4.23c1.4 0 2.63.7 3.37 1.76V5H5v10.04c1.39.63 2.5 1.87 2.5 3.46c0 .34-.06.67-.15.98H14.5zm3-2.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5s-1.12 2.5-2.5 2.5z" />
      </svg>;
    case "mail":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z" />
      </svg>;
    case "message-square":
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <path d="M2 4v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2zm18 12H6l-2 2V4h16v12z" />
      </svg>;
    default:
      return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
        <rect x="3" y="3" width="18" height="18" rx="2" />
      </svg>;
  }
};

export default function AppHistory() {
  const [activeTab, setActiveTab] = useState<"all" | "installed" | "deleted">("all");
  const { data: appHistoryData, isLoading, error, refetch } = useAppHistory();
  
  useEffect(() => {
    document.title = "AppInsight - App History";
  }, []);

  // Filter apps based on the active tab
  const filteredApps = React.useMemo(() => {
    if (!appHistoryData) return [];
    
    if (activeTab === "all") {
      return appHistoryData;
    } else {
      return appHistoryData.filter(app => app.status === activeTab);
    }
  }, [appHistoryData, activeTab]);
  
  return (
    <AppShell>
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <h2 className="text-sm text-neutral-600 dark:text-neutral-400">App Installation History</h2>
            <p className="text-xl font-semibold text-neutral-800 dark:text-white">{getFormattedDate()}</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 mt-4 sm:mt-0">
            <button 
              onClick={() => refetch()}
              disabled={isLoading}
              className="bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-800 dark:text-white flex items-center space-x-2 hover:bg-neutral-50 dark:hover:bg-neutral-700 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 text-neutral-600 dark:text-neutral-400 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            
            <Tabs defaultValue="all" className="w-full sm:w-auto" onValueChange={(value) => setActiveTab(value as "all" | "installed" | "deleted")}>
              <TabsList>
                <TabsTrigger value="all">All Apps</TabsTrigger>
                <TabsTrigger value="installed">Installed</TabsTrigger>
                <TabsTrigger value="deleted">Deleted</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Real Data Status */}
        {appHistoryData && appHistoryData.length > 0 && (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <p className="text-sm text-green-800 dark:text-green-200">
                Live app history data • {appHistoryData.length} app{appHistoryData.length !== 1 ? 's' : ''} tracked
              </p>
            </div>
          </div>
        )}
        
        <Card>
          <CardContent className="p-4 md:p-6">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center p-3 rounded-lg animate-pulse">
                    <div className="h-10 w-10 bg-gray-300 dark:bg-gray-600 rounded-xl mr-4"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-1/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredApps.map(app => (
                <div key={app.id} className="flex items-center p-3 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors">
                  <div 
                    className="h-10 w-10 rounded-xl mr-4 overflow-hidden flex-shrink-0 flex items-center justify-center text-xl" 
                    style={{ backgroundColor: app.color }}
                  >
                    {app.icon}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-neutral-800 dark:text-white truncate">{app.name}</h4>
                      <Badge variant={app.status === "installed" ? "outline" : "destructive"}>
                        {app.status === "installed" ? (
                          <Download className="h-3 w-3 mr-1" />
                        ) : (
                          <Trash2 className="h-3 w-3 mr-1" />
                        )}
                        {app.status === "installed" ? "Installed" : "Deleted"}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center mt-1 text-sm text-neutral-500 dark:text-neutral-400">
                      <div className="flex items-center mr-4">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>{app.date}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{app.time}</span>
                      </div>
                      <div className="ml-auto text-xs">
                        Size: {app.size}
                      </div>
                    </div>
                  </div>
                </div>
                ))}
                
                {filteredApps.length === 0 && (
                  <div className="py-8 text-center">
                    <p className="text-neutral-500 dark:text-neutral-400">No {activeTab !== "all" ? activeTab : ""} apps found in history.</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}