import { useEffect, useState } from "react";
import AppShell from "@/components/app-shell";
import StatsCard from "@/components/dashboard/stats-card";
import AppUsageChart from "@/components/dashboard/app-usage-chart";
import MostUsedApps from "@/components/dashboard/most-used-apps";
import StorageBreakdown from "@/components/dashboard/storage-breakdown";
import BatteryUsage from "@/components/dashboard/battery-usage";
import BatteryConsumption from "@/components/dashboard/battery-consumption";
import RealDataStatus from "@/components/real-data-status";
import DeviceInfoDisplay from "@/components/device-info-display";
import NativeFeaturesDashboard from "@/components/native-features-dashboard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getFormattedDate } from "@/lib/utils";
import { useDeviceStats, useSimulateAppUsage, transformDeviceStatsForDashboard } from "@/hooks/use-device-data";
import { Clock, Home, HardDrive, Battery, ArrowDown, ArrowUp, Filter, RefreshCw, Play, Smartphone } from "lucide-react";

export default function Dashboard() {
  const [isSimulating, setIsSimulating] = useState(false);
  const { data: deviceStats, isLoading, error, refetch } = useDeviceStats();
  const { simulateData } = useSimulateAppUsage();
  
  // Transform device stats for dashboard components
  const dashboardData = transformDeviceStatsForDashboard(deviceStats);

  // Update the document title
  useEffect(() => {
    document.title = "AppInsight - Dashboard";
  }, []);

  // Handle simulating app usage data
  const handleSimulateData = async () => {
    setIsSimulating(true);
    try {
      await simulateData();
    } catch (error) {
      console.error("Failed to simulate data:", error);
    } finally {
      setIsSimulating(false);
    }
  };

  if (error) {
    console.error("Error loading device stats:", error);
  }

  return (
    <AppShell>
      <div className="p-4 md:p-6 space-y-6">
        {/* Date and Filter Controls */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <h2 className="text-sm text-neutral-600 dark:text-neutral-400">Today's Overview</h2>
            <p className="text-xl font-semibold text-neutral-800 dark:text-white">{getFormattedDate()}</p>
          </div>
          
          <div className="flex mt-3 sm:mt-0 space-x-3">
            <button 
              onClick={() => refetch()}
              disabled={isLoading}
              className="bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg px-3 py-2 text-sm text-neutral-800 dark:text-white flex items-center space-x-2 hover:bg-neutral-50 dark:hover:bg-neutral-700 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 text-neutral-600 dark:text-neutral-400 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            
            <button 
              onClick={handleSimulateData}
              disabled={isSimulating}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-2 text-sm flex items-center space-x-2 disabled:opacity-50"
            >
              <Play className={`h-4 w-4 ${isSimulating ? 'animate-pulse' : ''}`} />
              <span>{isSimulating ? 'Simulating...' : 'Simulate Data'}</span>
            </button>
          </div>
        </div>

        {/* Real Data Capabilities */}
        <RealDataStatus />
        
        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Dashboard Overview</TabsTrigger>
            <TabsTrigger value="real-data">Real Device Data</TabsTrigger>
            <TabsTrigger value="native-features">Native App Features</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatsCard 
                title="Screen Time" 
                value={dashboardData.statsOverview.screenTime} 
                icon={<Clock className="h-5 w-5 text-primary" />} 
                trend={{
                  value: 12,
                  direction: "up"
                }} 
                type="time"
              />
              
              <StatsCard 
                title="App Usage" 
                value={dashboardData.statsOverview.appUsage} 
                icon={<Smartphone className="h-5 w-5 text-green-500" />} 
                trend={{
                  value: 8,
                  direction: "up"
                }} 
                type="number"
              />
              
              <StatsCard 
                title="Storage Used" 
                value={dashboardData.statsOverview.storageUsed} 
                icon={<HardDrive className="h-5 w-5 text-red-500" />} 
                progressValue={dashboardData.statsOverview.storagePercentage}
                type="storage"
              />
              
              <StatsCard 
                title="Battery Level" 
                value={dashboardData.statsOverview.batteryLevel} 
                icon={<Battery className="h-5 w-5 text-green-500" />} 
                remainingTime={dashboardData.statsOverview.batteryRemainingTime}
                type="battery"
              />
            </div>
            
            {/* Main Charts and App Usage */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm col-span-2 p-4">
                <h2 className="text-xl font-semibold mb-4 dark:text-white">App Usage Timeline</h2>
                <AppUsageChart />
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
                <h2 className="text-xl font-semibold mb-4 dark:text-white">Most Used Apps</h2>
                <MostUsedApps data={dashboardData.mostUsedApps} />
              </div>
            </div>
            
            {/* Storage and Battery Usage */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
                <h2 className="text-xl font-semibold mb-4 dark:text-white">Storage Breakdown</h2>
                <StorageBreakdown data={dashboardData.storageData} totalStorage={dashboardData.totalStorage} />
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
                <h2 className="text-xl font-semibold mb-4 dark:text-white">Battery Usage</h2>
                <BatteryUsage data={dashboardData.batteryData} />
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
                <h2 className="text-xl font-semibold mb-4 dark:text-white">Battery Consumption by App</h2>
                <BatteryConsumption data={dashboardData.mostUsedApps} />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="real-data" className="space-y-6">
            <DeviceInfoDisplay />
          </TabsContent>
          
          <TabsContent value="native-features" className="space-y-6">
            <NativeFeaturesDashboard />
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}
