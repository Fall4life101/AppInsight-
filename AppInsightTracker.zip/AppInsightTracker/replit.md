# AppInsight - Mobile App Usage Analytics

## Overview

AppInsight is a comprehensive mobile application analytics platform built as a web application with Android APK conversion capabilities. The application tracks and visualizes device usage patterns including app usage statistics, storage information, and battery consumption data. It features a modern React-based frontend with a Node.js/Express backend and uses PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### July 18, 2025 - Native App Conversion Implementation
- Added comprehensive native device service for accessing detailed device features
- Implemented native features dashboard showing real vs. simulated data capabilities
- Created detailed APK build guide with step-by-step instructions and code examples
- Added three-tab interface: Dashboard Overview, Real Device Data, Native App Features
- Prepared foundation for converting web app to native Android APK using Capacitor
- Developed mock data structure for native features that will be replaced by real native APIs

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: Radix UI components with custom styling
- **Styling**: Tailwind CSS with a custom design system
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Theme System**: Custom theme provider with light/dark mode support

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with structured error handling
- **Development**: Hot reload with Vite middleware integration

### Mobile Conversion
- **Hybrid Framework**: Capacitor for converting web app to native Android APK
- **Target Platform**: Android with HTTPS scheme configuration
- **Build Process**: Web-to-native conversion maintaining full functionality

## Key Components

### Data Models
The application tracks four main data types:
- **App Usage**: Application usage statistics including time spent and last used timestamps
- **Storage Info**: Device storage breakdown with total, used, and free space
- **Battery Info**: Battery level, charging status, and temperature data
- **Users**: Basic user management for data organization

### Frontend Components
- **Dashboard**: Main analytics view with real-time device statistics
- **App History**: Historical view of application installations and usage
- **App Shell**: Layout wrapper with responsive sidebar and top navigation
- **Stats Cards**: Reusable components for displaying key metrics
- **Charts**: Interactive visualizations for usage patterns and trends

### Backend Services
- **Storage Interface**: Abstracted data layer supporting both in-memory and database persistence
- **Real-time Monitor**: Device information collection and monitoring system
- **API Routes**: RESTful endpoints for all CRUD operations on device data

## Data Flow

1. **Data Collection**: Real-time monitoring collects device information through web APIs
2. **API Communication**: Frontend communicates with backend via RESTful API calls
3. **Data Persistence**: Backend stores data using Drizzle ORM with PostgreSQL
4. **Real-time Updates**: TanStack Query manages data fetching and caching
5. **Visualization**: React components render interactive charts and statistics

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React, React DOM, React Query for frontend functionality
- **UI Components**: Extensive Radix UI component library for accessible interfaces
- **Database**: Neon serverless PostgreSQL for cloud database hosting
- **Capacitor**: Mobile app conversion and native device access

### Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **Vite**: Development server and build tool with hot reload
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Drizzle Kit**: Database schema management and migrations

### Monitoring and Analytics
- **Device APIs**: Battery API, Storage API, Network Information API for real-time data
- **Query Client**: Centralized data fetching with caching and error handling

## Deployment Strategy

### Web Application
- **Build Process**: Vite builds optimized static assets to `dist/public`
- **Server Bundle**: ESBuild creates production server bundle in `dist`
- **Environment**: Supports both development and production configurations

### Android APK Generation
- **Capacitor Integration**: Configured for Android target with HTTPS scheme
- **Build Pipeline**: Web app builds first, then Capacitor converts to native APK
- **Distribution**: APK can be installed directly on Android devices

### Database Management
- **Schema**: Drizzle schema defines all database tables and relationships
- **Migrations**: Automated schema migrations through Drizzle Kit
- **Environment**: PostgreSQL connection via environment variable configuration

The application architecture prioritizes type safety, real-time data updates, and responsive design while maintaining the ability to convert to a native mobile application through Capacitor.