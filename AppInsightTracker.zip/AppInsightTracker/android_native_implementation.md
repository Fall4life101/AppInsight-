# Complete Native Android Implementation

## 1. MainActivity.java (Replace existing file)

```java
package com.example.appinsight;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Register all native plugins
        registerPlugin(UsageStatsPlugin.class);
        registerPlugin(BatteryInfoPlugin.class);
        registerPlugin(StorageInfoPlugin.class);
        registerPlugin(InstalledAppsPlugin.class);
        
        // Request usage access permission on first launch
        if (!hasUsageStatsPermission()) {
            requestUsageStatsPermission();
        }
    }
    
    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, 
                                        android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }
    
    private void requestUsageStatsPermission() {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        startActivity(intent);
    }
}
```

## 2. UsageStatsPlugin.java (Create new file)

```java
package com.example.appinsight;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.Calendar;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

@CapacitorPlugin(name = "UsageStats")
public class UsageStatsPlugin extends Plugin {
    
    @PluginMethod
    public void getAppUsageStats(PluginCall call) {
        try {
            UsageStatsManager usageStatsManager = (UsageStatsManager) 
                getContext().getSystemService(Context.USAGE_STATS_SERVICE);
            
            Calendar calendar = Calendar.getInstance();
            long endTime = calendar.getTimeInMillis();
            calendar.add(Calendar.DAY_OF_YEAR, -7); // Last 7 days
            long startTime = calendar.getTimeInMillis();
            
            List<UsageStats> usageStatsList = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, startTime, endTime);
            
            JSArray appsArray = new JSArray();
            PackageManager pm = getContext().getPackageManager();
            
            // Sort by usage time (most used first)
            Collections.sort(usageStatsList, new Comparator<UsageStats>() {
                @Override
                public int compare(UsageStats a, UsageStats b) {
                    return Long.compare(b.getTotalTimeInForeground(), a.getTotalTimeInForeground());
                }
            });
            
            for (UsageStats usageStats : usageStatsList) {
                if (usageStats.getTotalTimeInForeground() > 0) {
                    JSObject app = new JSObject();
                    try {
                        ApplicationInfo appInfo = pm.getApplicationInfo(usageStats.getPackageName(), 0);
                        String appName = pm.getApplicationLabel(appInfo).toString();
                        
                        app.put("appId", usageStats.getPackageName());
                        app.put("appName", appName);
                        app.put("usageTime", usageStats.getTotalTimeInForeground() / 1000 / 60); // minutes
                        app.put("lastUsed", usageStats.getLastTimeUsed());
                        app.put("launchCount", usageStats.getFirstTimeStamp());
                        
                        appsArray.put(app);
                    } catch (PackageManager.NameNotFoundException e) {
                        // App not found, skip
                    }
                }
            }
            
            JSObject result = new JSObject();
            result.put("apps", appsArray);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting app usage stats: " + e.getMessage());
        }
    }
}
```

## 3. BatteryInfoPlugin.java (Create new file)

```java
package com.example.appinsight;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;

@CapacitorPlugin(name = "BatteryInfo")
public class BatteryInfoPlugin extends Plugin {
    
    @PluginMethod
    public void getBatteryDetails(PluginCall call) {
        try {
            BatteryManager batteryManager = (BatteryManager) 
                getContext().getSystemService(Context.BATTERY_SERVICE);
            
            IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = getContext().registerReceiver(null, intentFilter);
            
            JSObject result = new JSObject();
            
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                String technology = batteryStatus.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
                
                result.put("level", Math.round((level * 100.0f) / scale));
                result.put("temperature", temperature / 10.0); // Convert to Celsius
                result.put("voltage", voltage / 1000.0); // Convert to volts
                result.put("isCharging", status == BatteryManager.BATTERY_STATUS_CHARGING);
                result.put("technology", technology != null ? technology : "Unknown");
                
                // Get battery health
                int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
                String healthString = "Unknown";
                switch (health) {
                    case BatteryManager.BATTERY_HEALTH_GOOD:
                        healthString = "Good";
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                        healthString = "Overheat";
                        break;
                    case BatteryManager.BATTERY_HEALTH_DEAD:
                        healthString = "Dead";
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                        healthString = "Over Voltage";
                        break;
                    case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                        healthString = "Unspecified Failure";
                        break;
                }
                result.put("health", healthString);
                
                // Get battery capacity (if available)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    int capacity = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                    result.put("capacity", capacity);
                }
            }
            
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting battery details: " + e.getMessage());
        }
    }
}
```

## 4. StorageInfoPlugin.java (Create new file)

```java
package com.example.appinsight;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.os.StatFs;
import android.os.Environment;
import android.content.Context;
import java.io.File;

@CapacitorPlugin(name = "StorageInfo")
public class StorageInfoPlugin extends Plugin {
    
    @PluginMethod
    public void getStorageBreakdown(PluginCall call) {
        try {
            JSObject result = new JSObject();
            
            // Internal storage
            StatFs internalStat = new StatFs(Environment.getDataDirectory().getPath());
            long internalTotal = internalStat.getTotalBytes();
            long internalFree = internalStat.getAvailableBytes();
            long internalUsed = internalTotal - internalFree;
            
            result.put("totalStorage", internalTotal);
            result.put("usedStorage", internalUsed);
            result.put("freeStorage", internalFree);
            result.put("usedPercentage", Math.round((internalUsed * 100.0f) / internalTotal));
            
            // External storage (if available)
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                StatFs externalStat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                long externalTotal = externalStat.getTotalBytes();
                long externalFree = externalStat.getAvailableBytes();
                long externalUsed = externalTotal - externalFree;
                
                result.put("externalTotal", externalTotal);
                result.put("externalUsed", externalUsed);
                result.put("externalFree", externalFree);
                result.put("hasExternalStorage", true);
            } else {
                result.put("hasExternalStorage", false);
            }
            
            // Cache directory size
            File cacheDir = getContext().getCacheDir();
            long cacheSize = getDirSize(cacheDir);
            result.put("cacheSize", cacheSize);
            
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting storage breakdown: " + e.getMessage());
        }
    }
    
    private long getDirSize(File dir) {
        long size = 0;
        if (dir != null && dir.exists()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        size += getDirSize(file);
                    } else {
                        size += file.length();
                    }
                }
            }
        }
        return size;
    }
}
```

## 5. InstalledAppsPlugin.java (Create new file)

```java
package com.example.appinsight;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.util.List;

@CapacitorPlugin(name = "InstalledApps")
public class InstalledAppsPlugin extends Plugin {
    
    @PluginMethod
    public void getInstalledApps(PluginCall call) {
        try {
            PackageManager pm = getContext().getPackageManager();
            List<PackageInfo> packages = pm.getInstalledPackages(PackageManager.GET_META_DATA);
            
            JSArray appsArray = new JSArray();
            
            for (PackageInfo packageInfo : packages) {
                JSObject app = new JSObject();
                ApplicationInfo appInfo = packageInfo.applicationInfo;
                
                // Skip system apps if requested
                boolean isSystemApp = (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                
                app.put("appId", packageInfo.packageName);
                app.put("appName", pm.getApplicationLabel(appInfo).toString());
                app.put("versionName", packageInfo.versionName);
                app.put("versionCode", packageInfo.versionCode);
                app.put("isSystemApp", isSystemApp);
                app.put("installTime", packageInfo.firstInstallTime);
                app.put("updateTime", packageInfo.lastUpdateTime);
                
                // Get app size (approximate)
                try {
                    long appSize = getAppSize(packageInfo.applicationInfo.sourceDir);
                    app.put("appSize", appSize);
                } catch (Exception e) {
                    app.put("appSize", 0);
                }
                
                appsArray.put(app);
            }
            
            JSObject result = new JSObject();
            result.put("apps", appsArray);
            result.put("totalApps", packages.size());
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Error getting installed apps: " + e.getMessage());
        }
    }
    
    private long getAppSize(String apkPath) {
        try {
            java.io.File file = new java.io.File(apkPath);
            return file.length();
        } catch (Exception e) {
            return 0;
        }
    }
}
```

## 6. AndroidManifest.xml (Add permissions)

Add these permissions to your `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
<uses-permission android:name="android.permission.BATTERY_STATS" />
<uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
<uses-permission android:name="android.permission.GET_TASKS" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

## 7. Build Commands

```bash
# Build APK
./gradlew assembleDebug

# Install on connected device
./gradlew installDebug

# Or build and install in one command
./gradlew build installDebug
```

## 8. Test APK Location

Your built APK will be at:
`android/app/build/outputs/apk/debug/app-debug.apk`

## 9. Grant Permissions After Installation

1. Install the APK on your device
2. Open the app
3. Go to Settings > Apps > AppInsight > Permissions
4. Grant "Usage Access" permission (most important)
5. Grant other permissions as needed

## That's It!

Once you follow these steps, your app will have full access to:
- Real app usage statistics
- Detailed battery information
- System storage breakdown
- Complete installed apps list
- Enhanced device information

The native features will automatically work once the app is installed on a real Android device.