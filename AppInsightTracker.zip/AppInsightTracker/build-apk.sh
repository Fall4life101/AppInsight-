
#!/bin/bash

echo "🚀 Building AppInsight APK..."

# Step 1: Install dependencies
echo "📦 Installing dependencies..."
npm install

# Step 2: Build web app
echo "🔨 Building web application..."
npm run build

# Step 3: Sync with Android
echo "📱 Syncing with Android platform..."
npx cap sync android

# Step 4: Build APK
echo "🏗️  Building APK..."
cd android
./gradlew assembleDebug

# Step 5: Show APK location
echo "✅ APK built successfully!"
echo "📍 APK Location: android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "🎯 Next steps:"
echo "1. Transfer APK to your Android device"
echo "2. Enable 'Unknown sources' in Android settings"
echo "3. Install the APK"
echo "4. Grant permissions when prompted"
echo ""
echo "📋 For installation help, see: APK_INSTALL_TROUBLESHOOTING.md"
