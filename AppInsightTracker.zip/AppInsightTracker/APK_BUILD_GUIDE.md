# APK Build Guide for AppInsight

This guide will help you convert the AppInsight web application into a native Android APK using Capacitor, enabling access to detailed device features that aren't available in web browsers.

## Prerequisites

1. **Node.js** (version 18 or higher)
2. **Android Studio** with Android SDK (API level 33 or higher)
3. **Java Development Kit (JDK)** 17 or higher
4. **Capacitor CLI** (already installed in this project)

## Step-by-Step Build Process

### 1. Install Android Studio
- Download and install Android Studio from [developer.android.com](https://developer.android.com/studio)
- Install the Android SDK through Android Studio (API level 33+)
- Set up the ANDROID_HOME environment variable:
  ```bash
  export ANDROID_HOME=$HOME/Library/Android/sdk  # macOS
  export ANDROID_HOME=$HOME/Android/Sdk          # Linux
  ```

### 2. Prepare the Web App
First, build the web application for production:

```bash
npm run build
```

This creates an optimized build in the `dist` folder that will be bundled into the APK.

### 3. Add Android Platform
If not already added, add the Android platform to your Capacitor project:

```bash
npx cap add android
```

### 4. Sync the Project
Sync the web app with the native Android project:

```bash
npx cap sync android
```

### 5. Open in Android Studio
Open the project in Android Studio to configure native features:

```bash
npx cap open android
```

### 6. Configure Permissions and Features

#### Add Required Permissions
Add these permissions to `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.BATTERY_STATS" />
<uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
<uses-permission android:name="android.permission.GET_TASKS" />
<uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

#### Request Usage Access Permission
Add this to your MainActivity.java to request usage access:

```java
import android.content.Intent;
import android.provider.Settings;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Request usage access permission
        if (!hasUsageStatsPermission()) {
            requestUsageStatsPermission();
        }
    }
    
    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, 
                                        android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }
    
    private void requestUsageStatsPermission() {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        startActivity(intent);
    }
}
```

### 7. Implement Native Features

#### Create Native Plugin for App Usage Statistics
Create `UsageStatsPlugin.java`:

```java
package com.example.appinsight;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.Calendar;
import java.util.List;

@CapacitorPlugin(name = "UsageStats")
public class UsageStatsPlugin extends Plugin {
    
    @PluginMethod
    public void getAppUsageStats(PluginCall call) {
        UsageStatsManager usageStatsManager = (UsageStatsManager) 
            getContext().getSystemService(Context.USAGE_STATS_SERVICE);
        
        Calendar calendar = Calendar.getInstance();
        long endTime = calendar.getTimeInMillis();
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        long startTime = calendar.getTimeInMillis();
        
        List<UsageStats> usageStatsList = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, startTime, endTime);
        
        JSArray appsArray = new JSArray();
        PackageManager pm = getContext().getPackageManager();
        
        for (UsageStats usageStats : usageStatsList) {
            if (usageStats.getTotalTimeInForeground() > 0) {
                JSObject app = new JSObject();
                try {
                    ApplicationInfo appInfo = pm.getApplicationInfo(usageStats.getPackageName(), 0);
                    String appName = pm.getApplicationLabel(appInfo).toString();
                    
                    app.put("appId", usageStats.getPackageName());
                    app.put("appName", appName);
                    app.put("usageTime", usageStats.getTotalTimeInForeground() / 1000 / 60); // minutes
                    app.put("lastUsed", usageStats.getLastTimeUsed());
                    
                    appsArray.put(app);
                } catch (PackageManager.NameNotFoundException e) {
                    // App not found, skip
                }
            }
        }
        
        JSObject result = new JSObject();
        result.put("apps", appsArray);
        call.resolve(result);
    }
}
```

#### Create Native Plugin for Battery Information
Create `BatteryInfoPlugin.java`:

```java
package com.example.appinsight;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

@CapacitorPlugin(name = "BatteryInfo")
public class BatteryInfoPlugin extends Plugin {
    
    @PluginMethod
    public void getBatteryDetails(PluginCall call) {
        BatteryManager batteryManager = (BatteryManager) 
            getContext().getSystemService(Context.BATTERY_SERVICE);
        
        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = getContext().registerReceiver(null, intentFilter);
        
        JSObject result = new JSObject();
        
        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            int voltage = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String technology = batteryStatus.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
            
            result.put("level", (level * 100) / scale);
            result.put("temperature", temperature / 10.0); // Convert to Celsius
            result.put("voltage", voltage / 1000.0); // Convert to volts
            result.put("isCharging", status == BatteryManager.BATTERY_STATUS_CHARGING);
            result.put("technology", technology);
            
            // Get battery health
            int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String healthString = "Unknown";
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    healthString = "Good";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    healthString = "Overheat";
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    healthString = "Dead";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    healthString = "Over Voltage";
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    healthString = "Unspecified Failure";
                    break;
            }
            result.put("health", healthString);
        }
        
        call.resolve(result);
    }
}
```

#### Create Native Plugin for Storage Information
Create `StorageInfoPlugin.java`:

```java
package com.example.appinsight;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.os.StatFs;
import android.os.Environment;

@CapacitorPlugin(name = "StorageInfo")
public class StorageInfoPlugin extends Plugin {
    
    @PluginMethod
    public void getStorageBreakdown(PluginCall call) {
        JSObject result = new JSObject();
        
        // Internal storage
        StatFs internalStat = new StatFs(Environment.getDataDirectory().getPath());
        long internalTotal = internalStat.getTotalBytes();
        long internalFree = internalStat.getAvailableBytes();
        long internalUsed = internalTotal - internalFree;
        
        result.put("totalStorage", internalTotal);
        result.put("usedStorage", internalUsed);
        result.put("freeStorage", internalFree);
        
        // External storage (if available)
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            StatFs externalStat = new StatFs(Environment.getExternalStorageDirectory().getPath());
            long externalTotal = externalStat.getTotalBytes();
            long externalFree = externalStat.getAvailableBytes();
            
            result.put("externalTotal", externalTotal);
            result.put("externalFree", externalFree);
        }
        
        call.resolve(result);
    }
}
```

#### Register Plugins in MainActivity
Add these plugins to your MainActivity.java:

```java
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Register native plugins
        registerPlugin(UsageStatsPlugin.class);
        registerPlugin(BatteryInfoPlugin.class);
        registerPlugin(StorageInfoPlugin.class);
    }
}
```

### 8. Update TypeScript Interface
Update your native device service to call the real native plugins:

```typescript
// In native-device-service.ts
import { Capacitor } from '@capacitor/core';

declare global {
  interface Window {
    UsageStats: {
      getAppUsageStats(): Promise<{ apps: any[] }>;
    };
    BatteryInfo: {
      getBatteryDetails(): Promise<any>;
    };
    StorageInfo: {
      getStorageBreakdown(): Promise<any>;
    };
  }
}

// Use these in your service methods
public async getDetailedAppUsage(): Promise<NativeDeviceInfo['appUsage']> {
  if (!this.isNative) {
    return this.getMockAppUsage();
  }

  try {
    const result = await window.UsageStats.getAppUsageStats();
    return result.apps;
  } catch (error) {
    console.error('Error getting app usage:', error);
    return this.getMockAppUsage();
  }
}
```

### 9. Build the APK

#### Debug Build
In Android Studio:
1. Select **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**
2. Wait for the build to complete
3. The APK will be generated in `android/app/build/outputs/apk/debug/`

#### Release Build
For a production release:
1. Generate a signed APK in Android Studio
2. Create a keystore for signing
3. Build the release APK

### 10. Testing the APK

1. **Enable Developer Options** on your Android device
2. **Enable USB Debugging**
3. **Install the APK** using:
   ```bash
   adb install android/app/build/outputs/apk/debug/app-debug.apk
   ```

### 11. Grant Permissions
After installing the APK:
1. Open the app
2. Go to **Settings** > **Apps** > **AppInsight** > **Permissions**
3. Grant **Usage Access** permission for detailed app statistics
4. Grant other required permissions as needed

## Key Features Unlocked in Native App

✅ **Detailed App Usage Statistics** - Real usage time, last used timestamps
✅ **System Storage Breakdown** - Apps, system, media, and other storage
✅ **Individual App Battery Consumption** - Per-app battery usage
✅ **Installed Apps List** - Complete list with sizes and versions
✅ **Enhanced Battery Information** - Temperature, voltage, health status
✅ **System Information** - Device model, OS version, memory details

## Publishing to Google Play Store

1. **Create a release build** with proper signing
2. **Create a Google Play Developer account** ($25 one-time fee)
3. **Upload the APK** to the Play Console
4. **Fill in app details**, screenshots, and descriptions
5. **Submit for review** (usually takes 1-3 days)

## Troubleshooting

- **Permission Denied**: Ensure all permissions are properly requested
- **Build Errors**: Check Android SDK and JDK versions
- **APK Won't Install**: Verify APK is properly signed
- **No Usage Data**: User must grant Usage Access permission manually

## Notes

- The web version shows limited data due to browser security restrictions
- Native app provides access to all device features shown in the "Native App Features" tab
- Consider implementing progressive enhancement for missing permissions
- Test on different Android versions (API 23+) and screen sizes
- Battery optimization settings may affect background data collection