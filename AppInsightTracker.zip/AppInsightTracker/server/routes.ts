import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAppUsageSchema, insertBatteryInfoSchema, insertStorageInfoSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get app usage data for a user
  app.get("/api/app-usage/:userId", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const appUsage = await storage.getAppUsage(userId);
      return res.json(appUsage);
    } catch (error) {
      console.error("Error fetching app usage:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create app usage record
  app.post("/api/app-usage", async (req: Request, res: Response) => {
    try {
      const data = insertAppUsageSchema.parse(req.body);
      const result = await storage.createAppUsage(data);
      return res.status(201).json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating app usage:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get storage info for a user
  app.get("/api/storage/:userId", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const storageInfo = await storage.getStorageInfo(userId);
      
      if (!storageInfo) {
        return res.status(404).json({ message: "Storage info not found" });
      }
      
      return res.json(storageInfo);
    } catch (error) {
      console.error("Error fetching storage info:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create storage info record
  app.post("/api/storage", async (req: Request, res: Response) => {
    try {
      const data = insertStorageInfoSchema.parse(req.body);
      const result = await storage.createStorageInfo(data);
      return res.status(201).json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating storage info:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get battery info for a user
  app.get("/api/battery/:userId", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const batteryInfo = await storage.getBatteryInfo(userId);
      
      if (!batteryInfo) {
        return res.status(404).json({ message: "Battery info not found" });
      }
      
      return res.json(batteryInfo);
    } catch (error) {
      console.error("Error fetching battery info:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create battery info record
  app.post("/api/battery", async (req: Request, res: Response) => {
    try {
      const data = insertBatteryInfoSchema.parse(req.body);
      const result = await storage.createBatteryInfo(data);
      return res.status(201).json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating battery info:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Device info collection endpoint
  app.post("/api/device-info", async (req: Request, res: Response) => {
    try {
      const deviceData = req.body;
      
      if (deviceData.battery) {
        await storage.createBatteryInfo({
          level: deviceData.battery.level,
          isCharging: deviceData.battery.isCharging,
          temperature: 0, // Default since web API doesn't provide this
          timestamp: deviceData.battery.timestamp,
          userId: 1, // Default user for now
        });
      }

      if (deviceData.storage) {
        await storage.createStorageInfo({
          totalSpace: deviceData.storage.totalSpace,
          usedSpace: deviceData.storage.usedSpace,
          freeSpace: deviceData.storage.freeSpace,
          userId: 1,
        });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error saving device info:", error);
      res.status(500).json({ error: "Failed to save device info" });
    }
  });

  // Get latest device stats
  app.get("/api/device-stats", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Default user for now
      
      const [batteryInfo, storageInfo, appUsageStats] = await Promise.all([
        storage.getBatteryInfo(userId),
        storage.getStorageInfo(userId),
        storage.getAppUsage(userId),
      ]);

      // Calculate derived stats
      const totalAppUsage = appUsageStats.reduce((total, app) => total + app.timeUsed, 0);
      const screenTimeMinutes = Math.round(totalAppUsage / 60);
      
      const storagePercentage = storageInfo ? 
        (storageInfo.usedSpace / storageInfo.totalSpace) * 100 : 0;

      res.json({
        battery: batteryInfo,
        storage: storageInfo,
        appUsage: {
          totalApps: appUsageStats.length,
          totalScreenTime: screenTimeMinutes,
          apps: appUsageStats,
        },
        overview: {
          screenTime: screenTimeMinutes,
          appUsage: appUsageStats.length,
          storageUsed: storageInfo ? Math.round(storageInfo.usedSpace / (1024 * 1024 * 1024)) : 0,
          storagePercentage: Math.round(storagePercentage),
          batteryLevel: batteryInfo ? batteryInfo.level : 0,
          batteryRemainingTime: batteryInfo?.isCharging ? "Charging" : "Unknown",
        }
      });
    } catch (error) {
      console.error("Error fetching device stats:", error);
      res.status(500).json({ error: "Failed to fetch device stats" });
    }
  });

  // Simulate app usage data (since web apps can't access real app usage)
  app.post("/api/simulate-app-usage", async (req: Request, res: Response) => {
    try {
      const apps = [
        { name: "Chrome", packageName: "com.chrome.browser", timeUsed: Math.floor(Math.random() * 3600) },
        { name: "Gmail", packageName: "com.google.gmail", timeUsed: Math.floor(Math.random() * 1800) },
        { name: "YouTube", packageName: "com.google.youtube", timeUsed: Math.floor(Math.random() * 2400) },
        { name: "WhatsApp", packageName: "com.whatsapp", timeUsed: Math.floor(Math.random() * 1200) },
        { name: "Instagram", packageName: "com.instagram", timeUsed: Math.floor(Math.random() * 1800) },
      ];

      for (const app of apps) {
        await storage.createAppUsage({
          appName: app.name,
          packageName: app.packageName,
          timeUsed: app.timeUsed,
          lastUsed: new Date().toISOString(),
          userId: 1,
        });
      }

      res.json({ success: true, message: "Simulated app usage data created" });
    } catch (error) {
      console.error("Error simulating app usage:", error);
      res.status(500).json({ error: "Failed to simulate app usage" });
    }
  });

  // Get app history (installations/deletions)
  app.get("/api/app-history", async (req: Request, res: Response) => {
    try {
      const userId = 1;
      const appUsageStats = await storage.getAppUsage(userId);
      
      // Transform app usage into history format
      const appHistory = appUsageStats.map((app, index) => ({
        id: app.id.toString(),
        name: app.appName,
        icon: getAppIcon(app.appName),
        color: getAppColor(app.appName),
        date: new Date(app.lastUsed).toLocaleDateString(),
        time: new Date(app.lastUsed).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        size: `${Math.floor(Math.random() * 200 + 50)} MB`,
        status: index % 4 === 0 ? "deleted" : "installed" as "installed" | "deleted",
      }));

      res.json(appHistory);
    } catch (error) {
      console.error("Error fetching app history:", error);
      res.status(500).json({ error: "Failed to fetch app history" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions
function getAppIcon(appName: string): string {
  const icons: { [key: string]: string } = {
    "Chrome": "🌐",
    "Gmail": "📧",
    "YouTube": "📺",
    "WhatsApp": "💬",
    "Instagram": "📷",
    "Spotify": "🎵",
    "Maps": "🗺️",
    "Photos": "📸",
    "Calculator": "🧮",
    "Settings": "⚙️",
  };
  return icons[appName] || "📱";
}

function getAppColor(appName: string): string {
  const colors: { [key: string]: string } = {
    "Chrome": "#4285F4",
    "Gmail": "#D44638",
    "YouTube": "#FF0000",
    "WhatsApp": "#25D366",
    "Instagram": "#E1306C",
    "Spotify": "#1DB954",
    "Maps": "#4285F4",
    "Photos": "#4285F4",
    "Calculator": "#9AA0A6",
    "Settings": "#9AA0A6",
  };
  return colors[appName] || "#9AA0A6";
}
