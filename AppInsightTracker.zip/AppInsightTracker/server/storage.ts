import { 
  User, 
  InsertUser, 
  AppUsage, 
  InsertAppUsage, 
  StorageInfo, 
  InsertStorageInfo, 
  BatteryInfo, 
  InsertBatteryInfo 
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // App usage methods
  getAppUsage(userId: number): Promise<AppUsage[]>;
  createAppUsage(usage: InsertAppUsage): Promise<AppUsage>;
  
  // Storage methods
  getStorageInfo(userId: number): Promise<StorageInfo | undefined>;
  createStorageInfo(info: InsertStorageInfo): Promise<StorageInfo>;
  
  // Battery methods
  getBatteryInfo(userId: number): Promise<BatteryInfo | undefined>;
  createBatteryInfo(info: InsertBatteryInfo): Promise<BatteryInfo>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private appUsages: Map<number, AppUsage[]>;
  private storageInfos: Map<number, StorageInfo>;
  private batteryInfos: Map<number, BatteryInfo>;
  
  private currentUserId: number;
  private currentAppUsageId: number;
  private currentStorageInfoId: number;
  private currentBatteryInfoId: number;

  constructor() {
    this.users = new Map();
    this.appUsages = new Map();
    this.storageInfos = new Map();
    this.batteryInfos = new Map();
    
    this.currentUserId = 1;
    this.currentAppUsageId = 1;
    this.currentStorageInfoId = 1;
    this.currentBatteryInfoId = 1;
    
    // Initialize with demo data
    this.createUser({username: "demo", password: "demo"}).then(user => {
      this.createStorageInfo({
        totalSpace: 128000000000, // 128 GB
        usedSpace: 69100000000, // 64.3 GB
        freeSpace: 58900000000, // 58.9 GB
        userId: user.id
      });
      
      this.createBatteryInfo({
        level: 73,
        isCharging: false,
        temperature: 280, // 28.0°C
        timestamp: new Date().toISOString(),
        userId: user.id
      });
      
      // Create some demo app usage data
      const apps = [
        { name: "Facebook", package: "com.facebook.katana", time: 4980 },
        { name: "Instagram", package: "com.instagram.android", time: 3120 },
        { name: "Twitter", package: "com.twitter.android", time: 2700 },
        { name: "WhatsApp", package: "com.whatsapp", time: 2280 },
        { name: "YouTube", package: "com.google.android.youtube", time: 1800 }
      ];
      
      apps.forEach(app => {
        this.createAppUsage({
          appName: app.name,
          packageName: app.package,
          timeUsed: app.time,
          lastUsed: new Date().toISOString(),
          userId: user.id
        });
      });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // App usage methods
  async getAppUsage(userId: number): Promise<AppUsage[]> {
    return this.appUsages.get(userId) || [];
  }
  
  async createAppUsage(usage: InsertAppUsage): Promise<AppUsage> {
    const id = this.currentAppUsageId++;
    const appUsage: AppUsage = { ...usage, id };
    
    if (!this.appUsages.has(usage.userId)) {
      this.appUsages.set(usage.userId, []);
    }
    
    this.appUsages.get(usage.userId)?.push(appUsage);
    return appUsage;
  }
  
  // Storage methods
  async getStorageInfo(userId: number): Promise<StorageInfo | undefined> {
    return this.storageInfos.get(userId);
  }
  
  async createStorageInfo(info: InsertStorageInfo): Promise<StorageInfo> {
    const id = this.currentStorageInfoId++;
    const storageInfo: StorageInfo = { ...info, id };
    this.storageInfos.set(info.userId, storageInfo);
    return storageInfo;
  }
  
  // Battery methods
  async getBatteryInfo(userId: number): Promise<BatteryInfo | undefined> {
    return this.batteryInfos.get(userId);
  }
  
  async createBatteryInfo(info: InsertBatteryInfo): Promise<BatteryInfo> {
    const id = this.currentBatteryInfoId++;
    const batteryInfo: BatteryInfo = { ...info, id };
    this.batteryInfos.set(info.userId, batteryInfo);
    return batteryInfo;
  }
}

export const storage = new MemStorage();
