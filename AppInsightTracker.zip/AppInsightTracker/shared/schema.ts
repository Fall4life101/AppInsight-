import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// App Usage schema
export const appUsage = pgTable("app_usage", {
  id: serial("id").primaryKey(),
  appName: text("app_name").notNull(),
  packageName: text("package_name").notNull(),
  timeUsed: integer("time_used").notNull(), // in seconds
  lastUsed: text("last_used").notNull(), // timestamp
  userId: integer("user_id").notNull(),
});

// Storage schema
export const storageInfo = pgTable("storage_info", {
  id: serial("id").primaryKey(),
  totalSpace: integer("total_space").notNull(), // in bytes
  usedSpace: integer("used_space").notNull(), // in bytes
  freeSpace: integer("free_space").notNull(), // in bytes
  userId: integer("user_id").notNull(),
});

// Battery schema
export const batteryInfo = pgTable("battery_info", {
  id: serial("id").primaryKey(),
  level: integer("level").notNull(), // percentage
  isCharging: boolean("is_charging").notNull(),
  temperature: integer("temperature").notNull(), // in tenths of a degree Celsius
  timestamp: text("timestamp").notNull(), // timestamp
  userId: integer("user_id").notNull(),
});

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Insert schemas
export const insertAppUsageSchema = createInsertSchema(appUsage).omit({
  id: true,
});

export const insertStorageInfoSchema = createInsertSchema(storageInfo).omit({
  id: true,
});

export const insertBatteryInfoSchema = createInsertSchema(batteryInfo).omit({
  id: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Types
export type InsertAppUsage = z.infer<typeof insertAppUsageSchema>;
export type AppUsage = typeof appUsage.$inferSelect;

export type InsertStorageInfo = z.infer<typeof insertStorageInfoSchema>;
export type StorageInfo = typeof storageInfo.$inferSelect;

export type InsertBatteryInfo = z.infer<typeof insertBatteryInfoSchema>;
export type BatteryInfo = typeof batteryInfo.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
